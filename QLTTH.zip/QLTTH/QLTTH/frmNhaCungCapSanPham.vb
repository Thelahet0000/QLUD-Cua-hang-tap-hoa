﻿Public Class frmNhaCungCapSanPham
    Public Shared TRANG_THAI_THEM = "Them"
    Public Shared TRANG_THAI_CAP_NHAT = "CapNhat"

    Public TrangThai As String
    Public NhaCungCap As DataRow
    Public NhaCungCapSanPham As DataRow

    Dim dsSanPham As DataTable

    Private Sub frmNhaCungCapSanPham_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lNhaCungCap.Text = NhaCungCap("ncc_code") + "-" + NhaCungCap("ncc_ten")

        dsSanPham = XL_DuLieu.DocDuLieu("select * from SanPham where sp_xoa=False")
        cbSanPham.DataSource = dsSanPham
        cbSanPham.ValueMember = "sp_ma"
        cbSanPham.DisplayMember = "sp_ten"

        If TrangThai = TRANG_THAI_CAP_NHAT Then
            cbSanPham.SelectedValue = NhaCungCapSanPham("nccsp_san_pham")
            tbGia.Text = NhaCungCapSanPham("nccsp_gia")

            bThem.Visible = False
        Else TrangThai = TRANG_THAI_THEM
            bCapNhat.Visible = False

        End If
    End Sub

    Private Sub bThem_Click(sender As Object, e As EventArgs) Handles bThem.Click
        NhaCungCapSanPham("nccsp_nha_cung_cap") = NhaCungCap("ncc_ma")
        NhaCungCapSanPham("ncc_ten") = NhaCungCap("ncc_ten")
        NhaCungCapSanPham("nccsp_san_pham") = cbSanPham.SelectedItem("sp_ma")
        NhaCungCapSanPham("sp_ten") = cbSanPham.SelectedItem("sp_ten")
        NhaCungCapSanPham("nccsp_gia") = tbGia.Text
        NhaCungCapSanPham("nccsp_ghi_chu") = tbGhiChu.Text
        NhaCungCapSanPham("nccsp_xoa") = False
    End Sub

    Private Sub bCapNhat_Click(sender As Object, e As EventArgs) Handles bCapNhat.Click
        NhaCungCapSanPham("nccsp_san_pham") = cbSanPham.SelectedItem("sp_ma")
        NhaCungCapSanPham("sp_ten") = cbSanPham.SelectedItem("sp_ten")
        NhaCungCapSanPham("nccsp_gia") = tbGia.Text
        NhaCungCapSanPham("nccsp_ghi_chu") = tbGhiChu.Text
    End Sub


End Class