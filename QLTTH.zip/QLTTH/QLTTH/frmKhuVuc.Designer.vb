﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKhuVuc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        dgvKhuVuc = New DataGridView()
        tbMa = New TextBox()
        lbMa = New Label()
        lbTen = New Label()
        lbMoTa = New Label()
        tbMota = New TextBox()
        tbTen = New TextBox()
        bThem = New Button()
        bCapNhat = New Button()
        bXoa = New Button()
        CType(dgvKhuVuc, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' dgvKhuVuc
        ' 
        dgvKhuVuc.AllowUserToAddRows = False
        dgvKhuVuc.AllowUserToDeleteRows = False
        dgvKhuVuc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvKhuVuc.Location = New Point(12, 12)
        dgvKhuVuc.Name = "dgvKhuVuc"
        dgvKhuVuc.ReadOnly = True
        dgvKhuVuc.Size = New Size(325, 426)
        dgvKhuVuc.TabIndex = 9
        ' 
        ' tbMa
        ' 
        tbMa.Location = New Point(521, 25)
        tbMa.Name = "tbMa"
        tbMa.Size = New Size(153, 23)
        tbMa.TabIndex = 0
        ' 
        ' lbMa
        ' 
        lbMa.AutoSize = True
        lbMa.Location = New Point(422, 28)
        lbMa.Name = "lbMa"
        lbMa.Size = New Size(24, 15)
        lbMa.TabIndex = 2
        lbMa.Text = "Ma"
        ' 
        ' lbTen
        ' 
        lbTen.AutoSize = True
        lbTen.Location = New Point(422, 71)
        lbTen.Name = "lbTen"
        lbTen.Size = New Size(25, 15)
        lbTen.TabIndex = 3
        lbTen.Text = "Ten"
        ' 
        ' lbMoTa
        ' 
        lbMoTa.AutoSize = True
        lbMoTa.Location = New Point(422, 110)
        lbMoTa.Name = "lbMoTa"
        lbMoTa.Size = New Size(38, 15)
        lbMoTa.TabIndex = 4
        lbMoTa.Text = "Mo ta"
        ' 
        ' tbMota
        ' 
        tbMota.Location = New Point(521, 107)
        tbMota.Name = "tbMota"
        tbMota.Size = New Size(153, 23)
        tbMota.TabIndex = 2
        ' 
        ' tbTen
        ' 
        tbTen.Location = New Point(521, 68)
        tbTen.Name = "tbTen"
        tbTen.Size = New Size(153, 23)
        tbTen.TabIndex = 1
        ' 
        ' bThem
        ' 
        bThem.Location = New Point(400, 169)
        bThem.Name = "bThem"
        bThem.Size = New Size(75, 23)
        bThem.TabIndex = 3
        bThem.Text = "Them"
        bThem.UseVisualStyleBackColor = True
        ' 
        ' bCapNhat
        ' 
        bCapNhat.Location = New Point(521, 169)
        bCapNhat.Name = "bCapNhat"
        bCapNhat.Size = New Size(75, 23)
        bCapNhat.TabIndex = 4
        bCapNhat.Text = "Cap Nhat"
        bCapNhat.UseVisualStyleBackColor = True
        ' 
        ' bXoa
        ' 
        bXoa.Location = New Point(649, 169)
        bXoa.Name = "bXoa"
        bXoa.Size = New Size(75, 23)
        bXoa.TabIndex = 5
        bXoa.Text = "Xoa"
        bXoa.UseVisualStyleBackColor = True
        ' 
        ' frmKhuVuc
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(bXoa)
        Controls.Add(bCapNhat)
        Controls.Add(bThem)
        Controls.Add(tbTen)
        Controls.Add(tbMota)
        Controls.Add(lbMoTa)
        Controls.Add(lbTen)
        Controls.Add(lbMa)
        Controls.Add(tbMa)
        Controls.Add(dgvKhuVuc)
        Name = "frmKhuVuc"
        Text = "frmKhuVuc"
        CType(dgvKhuVuc, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents dgvKhuVuc As DataGridView
    Friend WithEvents tbMa As TextBox
    Friend WithEvents lbMa As Label
    Friend WithEvents lbTen As Label
    Friend WithEvents lbMoTa As Label
    Friend WithEvents tbMota As TextBox
    Friend WithEvents tbTen As TextBox
    Friend WithEvents bThem As Button
    Friend WithEvents bCapNhat As Button
    Friend WithEvents bXoa As Button
End Class
