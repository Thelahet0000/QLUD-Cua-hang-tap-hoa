﻿Public Class frmBackupRestore
    Private Sub bBackup_Click(sender As Object, e As EventArgs) Handles bBackup.Click
        Try
            Dim backupfiledestination As String = Application.StartupPath & "\dbtest" & Format(Now(), "yyyy-M-d H m s") & ".accdb"
            Dim databaseFile As String = Application.StartupPath & "\dbtest.accdb"

            FileCopy(databaseFile, backupfiledestination)
            MsgBox("Du lieu Backup da duoc tao thanh cong!")
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub bRestore_Click(sender As Object, e As EventArgs) Handles bRestore.Click
        Try
            Dim restorefile As String = Application.StartupPath & "\dbtest.accdb"
            Dim msgText As String
            OpenFileDialog1.Filter = "Access | *.accdb"
            If OpenFileDialog1.ShowDialog = DialogResult.OK Then
                msgText = "Ban co muon restore du lieu?"
                If MessageBox.Show(msgText, "Restore", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.OK Then
                    FileCopy(OpenFileDialog1.FileName, restorefile)
                    MsgBox("Du lieu da duoc restore")
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

End Class