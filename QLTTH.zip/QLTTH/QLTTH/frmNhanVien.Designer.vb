﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNhanVien
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        bKhoiPhuc = New Button()
        cbKhoiPhuc = New CheckBox()
        tbTimKiem = New TextBox()
        bXoaNV = New Button()
        bCapNhatNV = New Button()
        bThemNV = New Button()
        tbDiaChiNV = New TextBox()
        tbTaiKhoanNV = New TextBox()
        lbTaiKhoanNV = New Label()
        lbDiaChiNV = New Label()
        lbTenNV = New Label()
        tbTenNV = New TextBox()
        dgvDanhSach = New DataGridView()
        tbMatKhauNV = New TextBox()
        lbMatKhauNV = New Label()
        GroupBox1 = New GroupBox()
        rbNu = New RadioButton()
        rbNam = New RadioButton()
        CType(dgvDanhSach, ComponentModel.ISupportInitialize).BeginInit()
        GroupBox1.SuspendLayout()
        SuspendLayout()
        ' 
        ' bKhoiPhuc
        ' 
        bKhoiPhuc.Location = New Point(652, 313)
        bKhoiPhuc.Name = "bKhoiPhuc"
        bKhoiPhuc.Size = New Size(75, 23)
        bKhoiPhuc.TabIndex = 35
        bKhoiPhuc.Text = "Khoi phuc"
        bKhoiPhuc.UseVisualStyleBackColor = True
        ' 
        ' cbKhoiPhuc
        ' 
        cbKhoiPhuc.AutoSize = True
        cbKhoiPhuc.Location = New Point(457, 316)
        cbKhoiPhuc.Name = "cbKhoiPhuc"
        cbKhoiPhuc.Size = New Size(179, 19)
        cbKhoiPhuc.TabIndex = 34
        cbKhoiPhuc.Text = "Hien thi cac nhan vien bi xoa"
        cbKhoiPhuc.UseVisualStyleBackColor = True
        ' 
        ' tbTimKiem
        ' 
        tbTimKiem.Location = New Point(21, 12)
        tbTimKiem.Name = "tbTimKiem"
        tbTimKiem.Size = New Size(414, 23)
        tbTimKiem.TabIndex = 33
        ' 
        ' bXoaNV
        ' 
        bXoaNV.Location = New Point(704, 265)
        bXoaNV.Name = "bXoaNV"
        bXoaNV.Size = New Size(75, 23)
        bXoaNV.TabIndex = 31
        bXoaNV.Text = "Xoa"
        bXoaNV.UseVisualStyleBackColor = True
        ' 
        ' bCapNhatNV
        ' 
        bCapNhatNV.Location = New Point(594, 265)
        bCapNhatNV.Name = "bCapNhatNV"
        bCapNhatNV.Size = New Size(75, 23)
        bCapNhatNV.TabIndex = 29
        bCapNhatNV.Text = "Cap Nhat"
        bCapNhatNV.UseVisualStyleBackColor = True
        ' 
        ' bThemNV
        ' 
        bThemNV.Location = New Point(486, 265)
        bThemNV.Name = "bThemNV"
        bThemNV.Size = New Size(75, 23)
        bThemNV.TabIndex = 27
        bThemNV.Text = "Them"
        bThemNV.UseVisualStyleBackColor = True
        ' 
        ' tbDiaChiNV
        ' 
        tbDiaChiNV.Location = New Point(585, 55)
        tbDiaChiNV.Name = "tbDiaChiNV"
        tbDiaChiNV.Size = New Size(153, 23)
        tbDiaChiNV.TabIndex = 24
        ' 
        ' tbTaiKhoanNV
        ' 
        tbTaiKhoanNV.Location = New Point(585, 189)
        tbTaiKhoanNV.Name = "tbTaiKhoanNV"
        tbTaiKhoanNV.Size = New Size(153, 23)
        tbTaiKhoanNV.TabIndex = 25
        ' 
        ' lbTaiKhoanNV
        ' 
        lbTaiKhoanNV.AutoSize = True
        lbTaiKhoanNV.Location = New Point(486, 192)
        lbTaiKhoanNV.Name = "lbTaiKhoanNV"
        lbTaiKhoanNV.Size = New Size(60, 15)
        lbTaiKhoanNV.TabIndex = 30
        lbTaiKhoanNV.Text = "Tai khoan:"
        ' 
        ' lbDiaChiNV
        ' 
        lbDiaChiNV.AutoSize = True
        lbDiaChiNV.Location = New Point(486, 58)
        lbDiaChiNV.Name = "lbDiaChiNV"
        lbDiaChiNV.Size = New Size(45, 15)
        lbDiaChiNV.TabIndex = 28
        lbDiaChiNV.Text = "DiaChi:"
        ' 
        ' lbTenNV
        ' 
        lbTenNV.AutoSize = True
        lbTenNV.Location = New Point(486, 15)
        lbTenNV.Name = "lbTenNV"
        lbTenNV.Size = New Size(28, 15)
        lbTenNV.TabIndex = 26
        lbTenNV.Text = "Ten:"
        ' 
        ' tbTenNV
        ' 
        tbTenNV.Location = New Point(585, 12)
        tbTenNV.Name = "tbTenNV"
        tbTenNV.Size = New Size(153, 23)
        tbTenNV.TabIndex = 23
        ' 
        ' dgvDanhSach
        ' 
        dgvDanhSach.AllowUserToAddRows = False
        dgvDanhSach.AllowUserToDeleteRows = False
        dgvDanhSach.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDanhSach.Location = New Point(21, 47)
        dgvDanhSach.Name = "dgvDanhSach"
        dgvDanhSach.ReadOnly = True
        dgvDanhSach.Size = New Size(414, 391)
        dgvDanhSach.TabIndex = 32
        ' 
        ' tbMatKhauNV
        ' 
        tbMatKhauNV.Location = New Point(585, 222)
        tbMatKhauNV.Name = "tbMatKhauNV"
        tbMatKhauNV.PasswordChar = "*"c
        tbMatKhauNV.Size = New Size(153, 23)
        tbMatKhauNV.TabIndex = 36
        ' 
        ' lbMatKhauNV
        ' 
        lbMatKhauNV.AutoSize = True
        lbMatKhauNV.Location = New Point(486, 225)
        lbMatKhauNV.Name = "lbMatKhauNV"
        lbMatKhauNV.Size = New Size(60, 15)
        lbMatKhauNV.TabIndex = 37
        lbMatKhauNV.Text = "Mat khau:"
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(rbNu)
        GroupBox1.Controls.Add(rbNam)
        GroupBox1.Location = New Point(486, 89)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(252, 77)
        GroupBox1.TabIndex = 38
        GroupBox1.TabStop = False
        GroupBox1.Text = "Gioi tinh:"
        ' 
        ' rbNu
        ' 
        rbNu.AutoSize = True
        rbNu.Location = New Point(130, 31)
        rbNu.Name = "rbNu"
        rbNu.Size = New Size(41, 19)
        rbNu.TabIndex = 1
        rbNu.TabStop = True
        rbNu.Text = "Nu"
        rbNu.UseVisualStyleBackColor = True
        ' 
        ' rbNam
        ' 
        rbNam.AutoSize = True
        rbNam.Location = New Point(6, 31)
        rbNam.Name = "rbNam"
        rbNam.Size = New Size(51, 19)
        rbNam.TabIndex = 0
        rbNam.TabStop = True
        rbNam.Text = "Nam"
        rbNam.UseVisualStyleBackColor = True
        ' 
        ' frmNhanVien
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(GroupBox1)
        Controls.Add(tbMatKhauNV)
        Controls.Add(lbMatKhauNV)
        Controls.Add(bKhoiPhuc)
        Controls.Add(cbKhoiPhuc)
        Controls.Add(tbTimKiem)
        Controls.Add(bXoaNV)
        Controls.Add(bCapNhatNV)
        Controls.Add(bThemNV)
        Controls.Add(tbDiaChiNV)
        Controls.Add(tbTaiKhoanNV)
        Controls.Add(lbTaiKhoanNV)
        Controls.Add(lbDiaChiNV)
        Controls.Add(lbTenNV)
        Controls.Add(tbTenNV)
        Controls.Add(dgvDanhSach)
        Name = "frmNhanVien"
        Text = "frmNhanVien"
        CType(dgvDanhSach, ComponentModel.ISupportInitialize).EndInit()
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents bKhoiPhuc As Button
    Friend WithEvents cbKhoiPhuc As CheckBox
    Friend WithEvents tbTimKiem As TextBox
    Friend WithEvents bXoaNV As Button
    Friend WithEvents bCapNhatNV As Button
    Friend WithEvents bThemNV As Button
    Friend WithEvents tbDiaChiNV As TextBox
    Friend WithEvents tbTaiKhoanNV As TextBox
    Friend WithEvents lbTaiKhoanNV As Label
    Friend WithEvents lbDiaChiNV As Label
    Friend WithEvents lbTenNV As Label
    Friend WithEvents tbTenNV As TextBox
    Friend WithEvents dgvDanhSach As DataGridView
    Friend WithEvents tbMatKhauNV As TextBox
    Friend WithEvents lbMatKhauNV As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbNam As RadioButton
    Friend WithEvents rbNu As RadioButton
End Class
