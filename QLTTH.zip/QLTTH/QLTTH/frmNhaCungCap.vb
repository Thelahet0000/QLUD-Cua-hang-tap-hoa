﻿Public Class frmNhaCungCap
    Dim dsNhaCungCap As DataTable
    Dim dsNhaCungCapView As DataView

    Dim dsSanPham As DataTable
    Dim dsSanPhamView As DataView

    Sub HienThiDSNhaCungCap()
        Dim truy_van As String = "Select * from NhaCungCap where ncc_xoa = " + cbKhoiPhuc.Checked.ToString()
        dsNhaCungCap = XL_DuLieu.DocDuLieu(truy_van)
        dsNhaCungCapView = New DataView(dsNhaCungCap)
        dgvDanhSach.DataSource = dsNhaCungCapView

        dgvDanhSach.Columns(0).Visible = False
        dgvDanhSach.Columns(6).Visible = False
    End Sub

    Sub HienThiDSSanPham(ByVal ncc_ma As String)
        Dim truy_van As String = String.Format("Select nccsp_ma, nccsp_nha_cung_cap, ncc_ten, nccsp_san_pham, sp_ten, nccsp_gia, nccsp_ghi_chu, nccsp_xoa from NhaCungCapSanPham, NhaCungCap, SanPham 
            where nccsp_nha_cung_cap = ncc_ma and nccsp_san_pham = sp_ma and 
            nccsp_nha_cung_cap = {0} and
            ncc_xoa = {1}", ncc_ma, cbKhoiPhuc.Checked.ToString())
        dsSanPham = XL_DuLieu.DocDuLieu(truy_van)
        dsSanPhamView = New DataView(dsSanPham)
        dgvDSSanPham.DataSource = dsSanPhamView

        dgvDSSanPham.Columns(0).Visible = False
        dgvDSSanPham.Columns(1).Visible = False
        dgvDSSanPham.Columns(3).Visible = False
        dgvDSSanPham.Columns(7).Visible = False
    End Sub
    Private Sub frmNhaCungCap_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim truy_van As String = "Select * from NhaCungCap where ncc_xoa = false"
        dsNhaCungCap = XL_DuLieu.DocDuLieu(truy_van)

        HienThiDSNhaCungCap()
        bKhoiPhuc.Enabled = False
    End Sub

    Private Sub bThem_Click(sender As Object, e As EventArgs) Handles bThem.Click
        Dim nhaCungCap As DataRow = dsNhaCungCap.NewRow()
        nhaCungCap("ncc_code") = tbMa.Text
        nhaCungCap("ncc_ten") = tbTen.Text
        nhaCungCap("ncc_dia_chi") = tbDiaChi.Text
        nhaCungCap("ncc_dien_thoai") = tbSdt.Text
        nhaCungCap("ncc_ghi_chu") = tbGhiChu.Text

        dsNhaCungCap.Rows.Add(nhaCungCap)
        XL_DuLieu.GhiDuLieu("NhaCungCap", dsNhaCungCap)
        MessageBox.Show("Them nha cung cap thanh cong", "Thong bao", MessageBoxButtons.OK)
    End Sub

    Private Sub bCapNhat_Click(sender As Object, e As EventArgs) Handles bCapNhat.Click
        If dgvDanhSach.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim nhaCungCapView As DataRowView = dgvDanhSach.Rows(row_index).DataBoundItem
            Dim nhaCungCap As DataRow = nhaCungCapView.Row

            nhaCungCap("ncc_code") = tbMa.Text
            nhaCungCap("ncc_ten") = tbTen.Text
            nhaCungCap("ncc_dia_chi") = tbDiaChi.Text
            nhaCungCap("ncc_dien_thoai") = tbSdt.Text
            nhaCungCap("ncc_ghi_chu") = tbGhiChu.Text

            XL_DuLieu.GhiDuLieu("NhaCungCap", dsNhaCungCap)
            MessageBox.Show("Cap nhat nha cung cap thanh cong", "Thong bao", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub bXoa_Click(sender As Object, e As EventArgs) Handles bXoa.Click
        If dgvDanhSach.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim nhaCungCapView As DataRowView = dgvDanhSach.Rows(row_index).DataBoundItem
            Dim nhaCungCap As DataRow = nhaCungCapView.Row

            Dim chuoi As String = String.Format("Anh/Chi co that su muon xoa '{0}' khong?", nhaCungCap("ncc_code"), nhaCungCap("ncc_ten"))
            Dim luachon As DialogResult = MessageBox.Show(chuoi, "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If luachon = DialogResult.Yes Then
                nhaCungCap("ncc_xoa") = True

                XL_DuLieu.GhiDuLieu("NhaCungCap", dsNhaCungCap)
                dsNhaCungCap.Rows.Remove(nhaCungCap)
                MessageBox.Show("Xoa san pham thanh cong", "Thong bao", MessageBoxButtons.OK)
            End If
        End If
    End Sub

    Private Sub dgvDanhSach_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDanhSach.CellClick
        If dgvDanhSach.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim nhaCungCapView As DataRowView = dgvDanhSach.Rows(row_index).DataBoundItem
            Dim nhaCungCap As DataRow = nhaCungCapView.Row

            tbMa.Text = nhaCungCap("ncc_code")
            tbTen.Text = nhaCungCap("ncc_ten")
            tbDiaChi.Text = nhaCungCap("ncc_dia_chi")
            tbSdt.Text = nhaCungCap("ncc_dien_thoai")
            tbGhiChu.Text = nhaCungCap("ncc_ghi_chu")

            HienThiDSSanPham(nhaCungCap("ncc_ma").ToString)
        End If
    End Sub

    Private Sub tbTimKiem_TextChanged(sender As Object, e As EventArgs) Handles tbTimKiem.TextChanged
        If tbTimKiem.Text <> "" Then
            dsNhaCungCapView.RowFilter = String.Format("ncc_ten like '%{0}%' or ncc_code like '%{0}%'", tbTimKiem.Text)
        Else
            dsNhaCungCapView.RowFilter = ""
        End If
    End Sub

    Private Sub cbKhoiPhuc_CheckedChanged(sender As Object, e As EventArgs) Handles cbKhoiPhuc.CheckedChanged
        HienThiDSNhaCungCap()
        If cbKhoiPhuc.Checked Then
            bKhoiPhuc.Enabled = True

            bThem.Enabled = False
            bCapNhat.Enabled = False
            bXoa.Enabled = False
        Else
            bKhoiPhuc.Enabled = False

            bThem.Enabled = True
            bCapNhat.Enabled = True
            bXoa.Enabled = True
        End If
    End Sub

    Private Sub bKhoiPhuc_Click(sender As Object, e As EventArgs) Handles bKhoiPhuc.Click
        If dgvDanhSach.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim nhaCungCapView As DataRowView = dgvDanhSach.Rows(row_index).DataBoundItem
            Dim nhaCungCap As DataRow = nhaCungCapView.Row

            Dim chuoi As String = String.Format("Anh/Chi co that su muon phuc hoi '{0}' khong?", nhaCungCap("ncc_code"), nhaCungCap("ncc_ten"))
            Dim luachon As DialogResult = MessageBox.Show(chuoi, "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If luachon = DialogResult.Yes Then
                nhaCungCap("ncc_xoa") = False

                XL_DuLieu.GhiDuLieu("NhaCungCap", dsNhaCungCap)
                dsNhaCungCap.Rows.Remove(nhaCungCap)
                MessageBox.Show("Khoi phuc nha cung cap thanh cong", "Thong bao", MessageBoxButtons.OK)
            End If
        End If
    End Sub

    Private Sub bThemSanPham_Click(sender As Object, e As EventArgs) Handles bThemSanPham.Click
        If dgvDanhSach.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim nhaCungCapView As DataRowView = dgvDanhSach.Rows(row_index).DataBoundItem
            Dim nhaCungCap As DataRow = nhaCungCapView.Row

            Dim frm As frmNhaCungCapSanPham = New frmNhaCungCapSanPham()
            frm.TrangThai = frmNhaCungCapSanPham.TRANG_THAI_THEM
            frm.NhaCungCap = nhaCungCap
            frm.NhaCungCapSanPham = dsSanPham.NewRow()

            Dim dr = frm.ShowDialog()
            If dr = DialogResult.OK Then
                dsSanPham.Rows.Add(frm.NhaCungCapSanPham)
                XL_DuLieu.GhiDuLieu("NhaCungCapSanPham", dsSanPham)
            End If
        Else
            MessageBox.Show("Vui long chon nha cung cap", "Thong bao")
        End If
    End Sub

    Private Sub bCapNhatSanPham_Click(sender As Object, e As EventArgs) Handles bCapNhatSanPham.Click
        If dgvDanhSach.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvDanhSach.SelectedCells(0).RowIndex
            Dim nhaCungCapView As DataRowView = dgvDanhSach.Rows(row_index).DataBoundItem
            Dim nhaCungCap As DataRow = nhaCungCapView.Row

            If dgvDanhSach.SelectedCells.Count() > 0 Then
                Dim row_index1 As Integer = dgvDSSanPham.SelectedCells(0).RowIndex
                Dim sanPhamView As DataRowView = dgvDSSanPham.Rows(row_index1).DataBoundItem
                Dim sanPham As DataRow = sanPhamView.Row

                Dim frm As frmNhaCungCapSanPham = New frmNhaCungCapSanPham()
                frm.TrangThai = frmNhaCungCapSanPham.TRANG_THAI_CAP_NHAT
                frm.NhaCungCap = nhaCungCap
                frm.NhaCungCapSanPham = sanPham

                Dim dr = frm.ShowDialog()
                If dr = DialogResult.OK Then
                    XL_DuLieu.GhiDuLieu("NhaCungCapSanPham", dsSanPham)
                End If
            Else
                MessageBox.Show("Vui long chon san pham", "Thong bao")

            End If
        Else
            MessageBox.Show("Vui long chon nha cung cap", "Thong bao")
        End If
    End Sub
End Class