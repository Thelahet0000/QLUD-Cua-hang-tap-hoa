﻿Public Class frmBanHang
    Public nhanVien As DataRow
    Private Sub frmBanHang_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dsNhanVien As DataTable = XL_DuLieu.DocCauTruc("Select * from NhanVien")
        nhanVien = dsNhanVien.NewRow()
        nhanVien("nv_ma") = 1

        HienThiDSDonHang()
    End Sub

    Public Sub HienThiDSDonHang()
        Dim str As String = String.Format(
            "Select * from DonHang")
        dgvDSDonHang.DataSource = XL_DuLieu.DocDuLieu(str)
    End Sub

    Private Sub bTaoDon_Click(sender As Object, e As EventArgs) Handles bTaoDon.Click
        Dim frm As frmDonHang = New frmDonHang()
        frm.ngay = dtpNgayHienTai.Value
        frm.Loai = 1
        frm.Tag = Me
        frm.Show()
        frm.WindowState = FormWindowState.Maximized

    End Sub

    Private Sub bCapNhat_Click(sender As Object, e As EventArgs) Handles bCapNhat.Click
        Dim frm As frmDonHang = New frmDonHang()
        frm.ngay = dtpNgayHienTai.Value
        frm.Loai = 2
        frm.Tag = Me
        If dgvDSDonHang.SelectedCells.Count > 0 Then
            Dim dhv As DataRowView = dgvDSDonHang.Rows(dgvDSDonHang.SelectedCells(0).RowIndex).DataBoundItem()
            Dim don_hang As DataRow = dhv.Row
            frm.don_hang = don_hang
            frm.Show()
            frm.WindowState = FormWindowState.Maximized
        End If
    End Sub
End Class