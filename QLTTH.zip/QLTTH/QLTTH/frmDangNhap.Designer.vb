﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDangNhap
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        bDangNhap = New Button()
        bThoat = New Button()
        tbTenDangNhap = New TextBox()
        tbMatKhau = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        lKetQua = New Label()
        SuspendLayout()
        ' 
        ' bDangNhap
        ' 
        bDangNhap.Location = New Point(350, 19)
        bDangNhap.Name = "bDangNhap"
        bDangNhap.Size = New Size(75, 23)
        bDangNhap.TabIndex = 0
        bDangNhap.Text = "Dang nhap"
        bDangNhap.UseVisualStyleBackColor = True
        ' 
        ' bThoat
        ' 
        bThoat.Location = New Point(350, 70)
        bThoat.Name = "bThoat"
        bThoat.Size = New Size(75, 23)
        bThoat.TabIndex = 1
        bThoat.Text = "Thoat"
        bThoat.UseVisualStyleBackColor = True
        ' 
        ' tbTenDangNhap
        ' 
        tbTenDangNhap.Location = New Point(147, 20)
        tbTenDangNhap.Name = "tbTenDangNhap"
        tbTenDangNhap.Size = New Size(177, 23)
        tbTenDangNhap.TabIndex = 2
        tbTenDangNhap.Text = "hnqcuong"
        ' 
        ' tbMatKhau
        ' 
        tbMatKhau.Location = New Point(147, 70)
        tbMatKhau.Name = "tbMatKhau"
        tbMatKhau.PasswordChar = "*"c
        tbMatKhau.Size = New Size(177, 23)
        tbMatKhau.TabIndex = 3
        tbMatKhau.Text = "cuong123"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(43, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(88, 15)
        Label1.TabIndex = 4
        Label1.Text = "Ten dang nhap:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(43, 78)
        Label2.Name = "Label2"
        Label2.Size = New Size(60, 15)
        Label2.TabIndex = 5
        Label2.Text = "Mat khau:"
        ' 
        ' lKetQua
        ' 
        lKetQua.AutoSize = True
        lKetQua.Location = New Point(166, 116)
        lKetQua.Name = "lKetQua"
        lKetQua.Size = New Size(0, 15)
        lKetQua.TabIndex = 6
        ' 
        ' frmDangNhap
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(474, 150)
        Controls.Add(lKetQua)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(tbMatKhau)
        Controls.Add(tbTenDangNhap)
        Controls.Add(bThoat)
        Controls.Add(bDangNhap)
        Name = "frmDangNhap"
        Text = "Dang Nhap"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents bDangNhap As Button
    Friend WithEvents bThoat As Button
    Friend WithEvents tbTenDangNhap As TextBox
    Friend WithEvents tbMatKhau As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lKetQua As Label
End Class
