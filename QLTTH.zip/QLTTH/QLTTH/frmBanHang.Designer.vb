﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBanHang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        tbTimKiem = New TextBox()
        bCapNhat = New Button()
        bTaoDon = New Button()
        dtpNgayHienTai = New DateTimePicker()
        dgvDSDonHang = New DataGridView()
        CType(dgvDSDonHang, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' tbTimKiem
        ' 
        tbTimKiem.Location = New Point(12, 9)
        tbTimKiem.Name = "tbTimKiem"
        tbTimKiem.Size = New Size(270, 23)
        tbTimKiem.TabIndex = 10
        ' 
        ' bCapNhat
        ' 
        bCapNhat.Location = New Point(503, 9)
        bCapNhat.Name = "bCapNhat"
        bCapNhat.Size = New Size(75, 23)
        bCapNhat.TabIndex = 9
        bCapNhat.Text = "Cap Nhat"
        bCapNhat.UseVisualStyleBackColor = True
        ' 
        ' bTaoDon
        ' 
        bTaoDon.Location = New Point(407, 8)
        bTaoDon.Name = "bTaoDon"
        bTaoDon.Size = New Size(75, 23)
        bTaoDon.TabIndex = 8
        bTaoDon.Text = "Tao don"
        bTaoDon.UseVisualStyleBackColor = True
        ' 
        ' dtpNgayHienTai
        ' 
        dtpNgayHienTai.CustomFormat = "dd/MM/yyyy"
        dtpNgayHienTai.Format = DateTimePickerFormat.Custom
        dtpNgayHienTai.Location = New Point(298, 9)
        dtpNgayHienTai.Name = "dtpNgayHienTai"
        dtpNgayHienTai.Size = New Size(85, 23)
        dtpNgayHienTai.TabIndex = 7
        ' 
        ' dgvDSDonHang
        ' 
        dgvDSDonHang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDSDonHang.Location = New Point(12, 40)
        dgvDSDonHang.Name = "dgvDSDonHang"
        dgvDSDonHang.Size = New Size(579, 366)
        dgvDSDonHang.TabIndex = 6
        ' 
        ' frmBanHang
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(tbTimKiem)
        Controls.Add(bCapNhat)
        Controls.Add(bTaoDon)
        Controls.Add(dtpNgayHienTai)
        Controls.Add(dgvDSDonHang)
        Name = "frmBanHang"
        Text = "BanHang"
        CType(dgvDSDonHang, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents tbTimKiem As TextBox
    Friend WithEvents bCapNhat As Button
    Friend WithEvents bTaoDon As Button
    Friend WithEvents dtpNgayHienTai As DateTimePicker
    Friend WithEvents dgvDSDonHang As DataGridView
End Class
