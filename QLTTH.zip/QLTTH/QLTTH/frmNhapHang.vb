﻿Public Class frmNhapHang
    Public nhanVien As DataRow
    Private Sub frmNhapHang_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dsNhanVien As DataTable = XL_DuLieu.DocCauTruc("Select * from NhanVien")
        nhanVien = dsNhanVien.NewRow()
        nhanVien("nv_ma") = 1

        HienThiDSNhapHang()
    End Sub

    Public Sub HienThiDSNhapHang()
        Dim str As String = String.Format(
            "Select * from PhieuNhap")
        dgvDSPhieuNhap.DataSource = XL_DuLieu.DocDuLieu(str)
    End Sub

    Private Sub bTaoDon_Click(sender As Object, e As EventArgs) Handles bTaoDon.Click
        Dim frm As frmPhieuNhap = New frmPhieuNhap()
        frm.ngay = dtpNgayHienTai.Value
        frm.Loai = 1
        frm.Tag = Me
        frm.Show()
        frm.WindowState = FormWindowState.Maximized

    End Sub

    Private Sub bCapNhat_Click(sender As Object, e As EventArgs) Handles bCapNhat.Click
        Dim frm As frmPhieuNhap = New frmPhieuNhap()
        frm.ngay = dtpNgayHienTai.Value
        frm.Loai = 2
        frm.Tag = Me
        If dgvDSPhieuNhap.SelectedCells.Count > 0 Then
            Dim dhv As DataRowView = dgvDSPhieuNhap.Rows(dgvDSPhieuNhap.SelectedCells(0).RowIndex).DataBoundItem()
            Dim phieu_nhap As DataRow = dhv.Row
            frm.phieu_nhap = phieu_nhap
            frm.Show()
            frm.WindowState = FormWindowState.Maximized
        End If
    End Sub
End Class