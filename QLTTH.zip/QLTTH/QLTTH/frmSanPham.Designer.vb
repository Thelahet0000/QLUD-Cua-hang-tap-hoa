﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSanPham
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        bXoaSP = New Button()
        bCapNhatSP = New Button()
        bThemSP = New Button()
        tbTenSP = New TextBox()
        tbMotaSP = New TextBox()
        lbMoTaSP = New Label()
        lbTenSP = New Label()
        lbMaSP = New Label()
        tbMaSP = New TextBox()
        dgvSanPham = New DataGridView()
        tbTimKiem = New TextBox()
        cbKhoiPhuc = New CheckBox()
        bKhoiPhuc = New Button()
        CType(dgvSanPham, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' bXoaSP
        ' 
        bXoaSP.Location = New Point(695, 156)
        bXoaSP.Name = "bXoaSP"
        bXoaSP.Size = New Size(75, 23)
        bXoaSP.TabIndex = 18
        bXoaSP.Text = "Xoa"
        bXoaSP.UseVisualStyleBackColor = True
        ' 
        ' bCapNhatSP
        ' 
        bCapNhatSP.Location = New Point(585, 156)
        bCapNhatSP.Name = "bCapNhatSP"
        bCapNhatSP.Size = New Size(75, 23)
        bCapNhatSP.TabIndex = 16
        bCapNhatSP.Text = "Cap Nhat"
        bCapNhatSP.UseVisualStyleBackColor = True
        ' 
        ' bThemSP
        ' 
        bThemSP.Location = New Point(477, 156)
        bThemSP.Name = "bThemSP"
        bThemSP.Size = New Size(75, 23)
        bThemSP.TabIndex = 14
        bThemSP.Text = "Them"
        bThemSP.UseVisualStyleBackColor = True
        ' 
        ' tbTenSP
        ' 
        tbTenSP.Location = New Point(576, 55)
        tbTenSP.Name = "tbTenSP"
        tbTenSP.Size = New Size(153, 23)
        tbTenSP.TabIndex = 11
        ' 
        ' tbMotaSP
        ' 
        tbMotaSP.Location = New Point(576, 94)
        tbMotaSP.Name = "tbMotaSP"
        tbMotaSP.Size = New Size(153, 23)
        tbMotaSP.TabIndex = 12
        ' 
        ' lbMoTaSP
        ' 
        lbMoTaSP.AutoSize = True
        lbMoTaSP.Location = New Point(477, 97)
        lbMoTaSP.Name = "lbMoTaSP"
        lbMoTaSP.Size = New Size(41, 15)
        lbMoTaSP.TabIndex = 17
        lbMoTaSP.Text = "Mo ta:"
        ' 
        ' lbTenSP
        ' 
        lbTenSP.AutoSize = True
        lbTenSP.Location = New Point(477, 58)
        lbTenSP.Name = "lbTenSP"
        lbTenSP.Size = New Size(28, 15)
        lbTenSP.TabIndex = 15
        lbTenSP.Text = "Ten:"
        ' 
        ' lbMaSP
        ' 
        lbMaSP.AutoSize = True
        lbMaSP.Location = New Point(477, 15)
        lbMaSP.Name = "lbMaSP"
        lbMaSP.Size = New Size(27, 15)
        lbMaSP.TabIndex = 13
        lbMaSP.Text = "Ma:"
        ' 
        ' tbMaSP
        ' 
        tbMaSP.Location = New Point(576, 12)
        tbMaSP.Name = "tbMaSP"
        tbMaSP.Size = New Size(153, 23)
        tbMaSP.TabIndex = 10
        ' 
        ' dgvSanPham
        ' 
        dgvSanPham.AllowUserToAddRows = False
        dgvSanPham.AllowUserToDeleteRows = False
        dgvSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvSanPham.Location = New Point(12, 47)
        dgvSanPham.Name = "dgvSanPham"
        dgvSanPham.ReadOnly = True
        dgvSanPham.Size = New Size(414, 391)
        dgvSanPham.TabIndex = 19
        ' 
        ' tbTimKiem
        ' 
        tbTimKiem.Location = New Point(12, 12)
        tbTimKiem.Name = "tbTimKiem"
        tbTimKiem.Size = New Size(414, 23)
        tbTimKiem.TabIndex = 20
        ' 
        ' cbKhoiPhuc
        ' 
        cbKhoiPhuc.AutoSize = True
        cbKhoiPhuc.Location = New Point(448, 207)
        cbKhoiPhuc.Name = "cbKhoiPhuc"
        cbKhoiPhuc.Size = New Size(179, 19)
        cbKhoiPhuc.TabIndex = 21
        cbKhoiPhuc.Text = "Hien thi cac san pham bi xoa"
        cbKhoiPhuc.UseVisualStyleBackColor = True
        ' 
        ' bKhoiPhuc
        ' 
        bKhoiPhuc.Location = New Point(643, 204)
        bKhoiPhuc.Name = "bKhoiPhuc"
        bKhoiPhuc.Size = New Size(75, 23)
        bKhoiPhuc.TabIndex = 22
        bKhoiPhuc.Text = "Khoi phuc"
        bKhoiPhuc.UseVisualStyleBackColor = True
        ' 
        ' frmSanPham
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(bKhoiPhuc)
        Controls.Add(cbKhoiPhuc)
        Controls.Add(tbTimKiem)
        Controls.Add(bXoaSP)
        Controls.Add(bCapNhatSP)
        Controls.Add(bThemSP)
        Controls.Add(tbTenSP)
        Controls.Add(tbMotaSP)
        Controls.Add(lbMoTaSP)
        Controls.Add(lbTenSP)
        Controls.Add(lbMaSP)
        Controls.Add(tbMaSP)
        Controls.Add(dgvSanPham)
        Name = "frmSanPham"
        Text = "frmSanPham"
        CType(dgvSanPham, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents bXoaSP As Button
    Friend WithEvents bCapNhatSP As Button
    Friend WithEvents bThemSP As Button
    Friend WithEvents tbTenSP As TextBox
    Friend WithEvents tbMotaSP As TextBox
    Friend WithEvents lbMoTaSP As Label
    Friend WithEvents lbTenSP As Label
    Friend WithEvents lbMaSP As Label
    Friend WithEvents tbMaSP As TextBox
    Friend WithEvents dgvSanPham As DataGridView
    Friend WithEvents tbTimKiem As TextBox
    Friend WithEvents cbKhoiPhuc As CheckBox
    Friend WithEvents bKhoiPhuc As Button
End Class
