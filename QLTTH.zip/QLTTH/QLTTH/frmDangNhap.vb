﻿Public Class frmDangNhap
    Public NhanVien As DataRow

    Private Sub bDangNhap_Click(sender As Object, e As EventArgs) Handles bDangNhap.Click
        Dim TenDangNhap As String = tbTenDangNhap.Text
        Dim MatKhau As String = tbMatKhau.Text
        Dim sql As String = String.Format("select TaiKhoan.*, NhanVien.* from NhanVien, TaiKhoan
            where tk_ma = nv_ma_tai_khoan and tk_tai_khoan = '{0}' and nv_xoa = false", TenDangNhap)
        Dim dsNDung As DataTable = XL_DuLieu.DocDuLieu(sql)
        If dsNDung.Rows.Count = 1 Then
            NhanVien = dsNDung.Rows(0)
            If MatKhau = NhanVien("tk_mat_khau") Then
                NhanVien("tk_dang_nhap_loi") = 0
                XL_DuLieu.GhiDuLieu("TaiKhoan", dsNDung)
                Me.DialogResult = DialogResult.OK
            Else
                NhanVien("tk_dang_nhap_loi") = NhanVien("tk_dang_nhap_loi") + 1
                XL_DuLieu.GhiDuLieu("TaiKhoan", dsNDung)
            End If
        End If
        lKetqua.Text = "Ten dang nhap/mat khau khong dung!!!"
    End Sub

    Private Sub bThoat_Click(sender As Object, e As EventArgs) Handles bThoat.Click
        Me.Close()
    End Sub

End Class