﻿Public Class frmKhuVuc
    Private dsKhuVuc As DataTable
    Private Sub frmKhuVuc_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim truy_van As String = "Select * from KhuVuc where kv_xoa = false"
        dsKhuVuc = XL_DuLieu.DocDuLieu(truy_van)

        dgvKhuVuc.DataSource = dsKhuVuc
        dgvKhuVuc.Columns(0).Visible = False
        dgvKhuVuc.Columns(4).Visible = False
        dgvKhuVuc.Columns(1).HeaderText = "Ma"
        dgvKhuVuc.Columns(2).HeaderText = "Ten"
        dgvKhuVuc.Columns(3).HeaderText = "Mo ta"
    End Sub

    Private Sub bThem_Click(sender As Object, e As EventArgs) Handles bThem.Click
        Dim KhuVuc As DataRow = dsKhuVuc.NewRow()

        KhuVuc("kv_code") = tbMa.Text
        KhuVuc("kv_ten") = tbTen.Text
        KhuVuc("kv_mo_ta") = tbMota.Text
        KhuVuc("kv_xoa") = False

        dsKhuVuc.Rows.Add(KhuVuc)
        XL_DuLieu.GhiDuLieu("KhuVuc", dsKhuVuc)
        MessageBox.Show("Them danh muc thanh cong", "Thong bao", MessageBoxButtons.OK)
    End Sub

    Private Sub dgvKhuVuc_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvKhuVuc.CellContentClick
        If dgvKhuVuc.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvKhuVuc.SelectedCells(0).RowIndex
            Dim khuvucView As DataRowView = dgvKhuVuc.Rows(row_index).DataBoundItem
            Dim khuvuc As DataRow = khuvucView.Row

            tbMa.Text = khuvuc("kv_code")
            tbTen.Text = khuvuc("kv_ten")
            tbMota.Text = khuvuc("kv_mo_ta")
        End If
    End Sub

    Private Sub bCapNhat_Click(sender As Object, e As EventArgs) Handles bCapNhat.Click
        If dgvKhuVuc.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvKhuVuc.SelectedCells(0).RowIndex
            Dim khuvucView As DataRowView = dgvKhuVuc.Rows(row_index).DataBoundItem
            Dim khuvuc As DataRow = khuvucView.Row

            khuvuc("kv_code") = tbMa.Text
            khuvuc("kv_ten") = tbTen.Text
            khuvuc("kv_mo_ta") = tbMota.Text

            XL_DuLieu.GhiDuLieu("KhuVuc", dsKhuVuc)
            MessageBox.Show("Cap nhat danh muc thanh cong", "Thong bao", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub bXoa_Click(sender As Object, e As EventArgs) Handles bXoa.Click
        If dgvKhuVuc.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvKhuVuc.SelectedCells(0).RowIndex
            Dim khuvucView As DataRowView = dgvKhuVuc.Rows(row_index).DataBoundItem
            Dim khuvuc As DataRow = khuvucView.Row

            khuvuc("kv_xoa") = True

            XL_DuLieu.GhiDuLieu("KhuVuc", dsKhuVuc)
            dsKhuVuc.Rows.Remove(khuvuc)
            MessageBox.Show("Xoa danh muc thanh cong", "Thong bao", MessageBoxButtons.OK)
        End If
    End Sub
End Class