﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDonHang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        dgvDSSanPham = New DataGridView()
        dtpNgay = New DateTimePicker()
        lNgay = New Label()
        Label1 = New Label()
        tbDienThoai = New TextBox()
        tbGhiChu = New TextBox()
        Label2 = New Label()
        dgvDSChiTiet = New DataGridView()
        bThem = New Button()
        bXoa = New Button()
        lbTongTien = New Label()
        bTao = New Button()
        bCapNhat = New Button()
        Label3 = New Label()
        tbDiaChi = New TextBox()
        tbTen = New TextBox()
        Label4 = New Label()
        CType(dgvDSSanPham, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgvDSChiTiet, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' dgvDSSanPham
        ' 
        dgvDSSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDSSanPham.Location = New Point(12, 12)
        dgvDSSanPham.Name = "dgvDSSanPham"
        dgvDSSanPham.Size = New Size(414, 482)
        dgvDSSanPham.TabIndex = 8
        ' 
        ' dtpNgay
        ' 
        dtpNgay.CustomFormat = "dd/MM/yyyy"
        dtpNgay.Format = DateTimePickerFormat.Custom
        dtpNgay.Location = New Point(610, 12)
        dtpNgay.Name = "dtpNgay"
        dtpNgay.Size = New Size(85, 23)
        dtpNgay.TabIndex = 1
        ' 
        ' lNgay
        ' 
        lNgay.AutoSize = True
        lNgay.Location = New Point(521, 18)
        lNgay.Name = "lNgay"
        lNgay.Size = New Size(38, 15)
        lNgay.TabIndex = 2
        lNgay.Text = "Ngay:"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(521, 49)
        Label1.Name = "Label1"
        Label1.Size = New Size(64, 15)
        Label1.TabIndex = 3
        Label1.Text = "Dien thoai:"
        ' 
        ' tbDienThoai
        ' 
        tbDienThoai.Location = New Point(610, 41)
        tbDienThoai.Name = "tbDienThoai"
        tbDienThoai.Size = New Size(129, 23)
        tbDienThoai.TabIndex = 0
        ' 
        ' tbGhiChu
        ' 
        tbGhiChu.Location = New Point(610, 105)
        tbGhiChu.Name = "tbGhiChu"
        tbGhiChu.Size = New Size(337, 23)
        tbGhiChu.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(521, 113)
        Label2.Name = "Label2"
        Label2.Size = New Size(51, 15)
        Label2.TabIndex = 6
        Label2.Text = "Ghi chu:"
        ' 
        ' dgvDSChiTiet
        ' 
        dgvDSChiTiet.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDSChiTiet.Location = New Point(518, 134)
        dgvDSChiTiet.Name = "dgvDSChiTiet"
        dgvDSChiTiet.Size = New Size(545, 360)
        dgvDSChiTiet.TabIndex = 7
        ' 
        ' bThem
        ' 
        bThem.Location = New Point(432, 178)
        bThem.Name = "bThem"
        bThem.Size = New Size(75, 23)
        bThem.TabIndex = 4
        bThem.Text = ">"
        bThem.UseVisualStyleBackColor = True
        ' 
        ' bXoa
        ' 
        bXoa.Location = New Point(433, 207)
        bXoa.Name = "bXoa"
        bXoa.Size = New Size(75, 23)
        bXoa.TabIndex = 5
        bXoa.Text = "<"
        bXoa.UseVisualStyleBackColor = True
        ' 
        ' lbTongTien
        ' 
        lbTongTien.AutoSize = True
        lbTongTien.Location = New Point(1007, 508)
        lbTongTien.Name = "lbTongTien"
        lbTongTien.Size = New Size(56, 15)
        lbTongTien.TabIndex = 10
        lbTongTien.Text = "Tong tien"
        ' 
        ' bTao
        ' 
        bTao.Location = New Point(988, 576)
        bTao.Name = "bTao"
        bTao.Size = New Size(75, 23)
        bTao.TabIndex = 7
        bTao.Text = "Tao"
        bTao.UseVisualStyleBackColor = True
        ' 
        ' bCapNhat
        ' 
        bCapNhat.Location = New Point(987, 547)
        bCapNhat.Name = "bCapNhat"
        bCapNhat.Size = New Size(75, 23)
        bCapNhat.TabIndex = 6
        bCapNhat.Text = "Cap Nhat"
        bCapNhat.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(521, 82)
        Label3.Name = "Label3"
        Label3.Size = New Size(46, 15)
        Label3.TabIndex = 16
        Label3.Text = "Dia chi:"
        ' 
        ' tbDiaChi
        ' 
        tbDiaChi.Location = New Point(610, 74)
        tbDiaChi.Name = "tbDiaChi"
        tbDiaChi.Size = New Size(337, 23)
        tbDiaChi.TabIndex = 2
        ' 
        ' tbTen
        ' 
        tbTen.Location = New Point(798, 41)
        tbTen.Name = "tbTen"
        tbTen.Size = New Size(149, 23)
        tbTen.TabIndex = 1
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(764, 49)
        Label4.Name = "Label4"
        Label4.Size = New Size(28, 15)
        Label4.TabIndex = 13
        Label4.Text = "Ten:"
        ' 
        ' frmDonHang
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1083, 636)
        Controls.Add(Label3)
        Controls.Add(tbDiaChi)
        Controls.Add(tbTen)
        Controls.Add(Label4)
        Controls.Add(bTao)
        Controls.Add(bCapNhat)
        Controls.Add(lbTongTien)
        Controls.Add(bXoa)
        Controls.Add(bThem)
        Controls.Add(dgvDSChiTiet)
        Controls.Add(Label2)
        Controls.Add(tbGhiChu)
        Controls.Add(tbDienThoai)
        Controls.Add(Label1)
        Controls.Add(lNgay)
        Controls.Add(dtpNgay)
        Controls.Add(dgvDSSanPham)
        Name = "frmDonHang"
        Text = "Don Hang"
        CType(dgvDSSanPham, ComponentModel.ISupportInitialize).EndInit()
        CType(dgvDSChiTiet, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents dgvDSSanPham As DataGridView
    Friend WithEvents dtpNgayHienTai As DateTimePicker
    Friend WithEvents lNgay As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents tbDienThoai As TextBox
    Friend WithEvents tbGhiChu As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents dgvDSChiTiet As DataGridView
    Friend WithEvents bThem As Button
    Friend WithEvents bXoa As Button
    Friend WithEvents dtpNgay As DateTimePicker
    Friend WithEvents lbTongTien As Label
    Friend WithEvents bTao As Button
    Friend WithEvents bCapNhat As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents tbDiaChi As TextBox
    Friend WithEvents tbTen As TextBox
    Friend WithEvents Label4 As Label
End Class
