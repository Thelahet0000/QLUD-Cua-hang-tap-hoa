﻿Public Class frmPhieuNhap
    Public ngay As Date

    Dim dsSanPham As DataTable
    Dim dsChiTietPhieuNhap As DataTable
    Dim dsPhieuNhap As DataTable
    Dim dsKhuVuc As DataTable

    Dim dsNhaCungCap As DataTable
    Dim nha_cung_cap As DataRow

    Public Loai As Integer
    Public phieu_nhap As DataRow
    Private Sub frmPhieuNhapHang_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim truy_van As String = "Select * from KhuVuc where kv_xoa = false"
        dsKhuVuc = XL_DuLieu.DocDuLieu(truy_van)
        cbKhuVuc.DataSource = dsKhuVuc
        cbKhuVuc.ValueMember = "kv_ma"
        cbKhuVuc.DisplayMember = "kv_ten"


        dtpNgay.Value = ngay
        Dim str As String = String.Format(
            "Select sp_ma, sp_ten, nccsp_gia from NhaCungCapSanPham, SanPham
                where nccsp_san_pham = sp_ma")
        dsSanPham = XL_DuLieu.DocDuLieu(str)
        dgvDSSanPham.DataSource = dsSanPham

        If Loai = 1 Then
            str = String.Format(
                "Select ctpn_ma, ctpn_ma_phieu_nhap, ctpn_ma_san_pham, sp_ten, ctpn_so_luong, ctpn_gia , 
                ctpn_tong_san_pham, ctpn_khuyen_mai, ctpn_tong_tien, ctpn_ghi_chu, ctpn_ma_khu_vuc, ctpn_xoa
                from ChiTietPhieuNhap, SanPham where ctpn_ma_san_pham = sp_ma"
            )
            dsChiTietPhieuNhap = XL_DuLieu.DocCauTruc(str)

            str = String.Format("select * from PhieuNhap")
            dsPhieuNhap = XL_DuLieu.DocCauTruc(str)
            bCapNhat.Visible = False
            bTao.Visible = True
        Else
            dsChiTietPhieuNhap = XL_DuLieu.DocDuLieu(
                "Select ctpn_ma, ctpn_ma_phieu_nhap, ctpn_ma_san_pham, sp_ten, ctpn_so_luong, ctpn_gia , 
                ctpn_tong_san_pham, ctpn_khuyen_mai, ctpn_tong_tien, ctpn_ghi_chu, ctpn_ma_khu_vuc, ctpn_xoa
                from ChiTietPhieuNhap, SanPham where ctpn_ma_san_pham = sp_ma and ctpn_ma_phieu_nhap=" + phieu_nhap("pn_ma").ToString()
            )
            dsPhieuNhap = XL_DuLieu.DocDuLieu(
                "Select * from PhieuNhap where pn_ma = " + phieu_nhap("pn_ma").ToString()
            )

            dsNhaCungCap = XL_DuLieu.DocDuLieu("select * from NhaCungCap where ncc_ma=" + phieu_nhap("pn_nccach_hang").ToString)
            nha_cung_cap = dsNhaCungCap.Rows(0)
            tbDienThoai.Text = nha_cung_cap("ncc_dien_thoai")
            tbTen.Text = nha_cung_cap("ncc_ten")
            tbDiaChi.Text = nha_cung_cap("ncc_dia_chi")
            TinhTong()
            bCapNhat.Visible = True
            bTao.Visible = False
        End If
        dgvDSChiTiet.DataSource = dsChiTietPhieuNhap
        dgvDSChiTiet.Columns(0).Visible = False
        dgvDSChiTiet.Columns(0).Visible = False
    End Sub

    Private Sub tbDienThoai_TextChanged(sender As Object, e As EventArgs) Handles tbDienThoai.TextChanged, tbDienThoai.Leave
        Dim str As String = String.Format("Select * from NhaCungCap where ncc_dien_thoai like '{0}'", tbDienThoai.Text)
        dsNhaCungCap = XL_DuLieu.DocDuLieu(str)
        If dsNhaCungCap.Rows.Count > 0 Then
            nha_cung_cap = dsNhaCungCap.Rows(0)
            tbTen.Text = nha_cung_cap("ncc_ten")
            tbDiaChi.Text = nha_cung_cap("ncc_dia_chi")
        Else
            nha_cung_cap = dsNhaCungCap.NewRow()
            nha_cung_cap("ncc_dien_thoai") = tbDienThoai.Text
            dsNhaCungCap.Rows.Add(nha_cung_cap)
        End If
    End Sub

    Sub TinhTong()
        Dim TongTien = dsChiTietPhieuNhap.Compute("Sum(ctpn_tong_tien)", String.Empty)
        lbTongTien.Text = TongTien.ToString()
    End Sub

    Private Sub bThem_Click(sender As Object, e As EventArgs) Handles bThem.Click
        If dgvDSSanPham.SelectedRows.Count > 0 Then
            Dim san_pham As DataRow = dsSanPham(dgvDSSanPham.SelectedCells(0).RowIndex)
            Dim ctpns() As DataRow = dsChiTietPhieuNhap.Select("ctpn_ma_san_pham = " + san_pham("sp_ma").ToString())

            If ctpns.Length > 0 Then
                Dim chi_tiet As DataRow = ctpns(0)
                chi_tiet("ctpn_so_luong") += 1
                chi_tiet("ctpn_tong_tien") = chi_tiet("ctpn_so_luong") * chi_tiet("ctpn_gia")
                chi_tiet("ctpn_tong_san_pham") = chi_tiet("ctpn_tong_tien")
                chi_tiet("ctpn_khuyen_mai") = 0
                chi_tiet("ctpn_ma_khu_vuc") = cbKhuVuc.SelectedValue
            Else
                Dim chi_tiet As DataRow = dsChiTietPhieuNhap.NewRow()
                chi_tiet("ctpn_ma_san_pham") = san_pham("sp_ma")
                chi_tiet("ctpn_gia") = san_pham("nccsp_gia")
                chi_tiet("ctpn_so_luong") = 1
                chi_tiet("sp_ten") = san_pham("sp_ten")
                chi_tiet("ctpn_tong_tien") = chi_tiet("ctpn_so_luong") * chi_tiet("ctpn_gia")
                chi_tiet("ctpn_tong_san_pham") = chi_tiet("ctpn_tong_tien")
                chi_tiet("ctpn_khuyen_mai") = 0
                chi_tiet("ctpn_ma_khu_vuc") = cbKhuVuc.SelectedValue
                dsChiTietPhieuNhap.Rows.Add(chi_tiet)
            End If
            TinhTong()
        End If
    End Sub

    Private Sub bXoa_Click(sender As Object, e As EventArgs) Handles bXoa.Click
        If dgvDSSanPham.SelectedRows.Count > 0 Then
            Dim chi_tiet As DataRow = dsChiTietPhieuNhap(dgvDSChiTiet.SelectedCells(0).RowIndex)
            Dim so_luong As Integer = chi_tiet("ctpn_so_luong") - 1
            If so_luong <= 0 Then
                If Loai = 1 Then
                    dsChiTietPhieuNhap.Rows.Remove(chi_tiet)
                ElseIf Loai = 2 Then
                    chi_tiet.Delete()
                End If
            Else
                chi_tiet("ctpn_so_luong") = so_luong
                chi_tiet("ctpn_tong_tien") = chi_tiet("ctpn_so_luong") * chi_tiet("ctpn_gia")
                chi_tiet("ctpn_tong_san_pham") = chi_tiet("ctpn_tong_tien")
                chi_tiet("ctpn_khuyen_mai") = 0
            End If
            TinhTong()
        End If
    End Sub

    Private Sub bTao_Click(sender As Object, e As EventArgs) Handles bTao.Click
        If tbDienThoai.Text = "" Or tbTen.Text = "" Then
            MessageBox.Show("Vui long dien thong tin nha cung cap!", "Thong bao")
            Return
        Else
            If IsDBNull(nha_cung_cap("ncc_ma")) Then
                nha_cung_cap("ncc_ten") = tbTen.Text
                nha_cung_cap("ncc_dia_chi") = tbDiaChi.Text
                XL_DuLieu.GhiDuLieu("NhaCungCap", dsNhaCungCap)
            End If
        End If

        Dim phieu_nhap = dsPhieuNhap.NewRow()
        phieu_nhap("pn_ngay") = dtpNgay.Value
        phieu_nhap("pn_tong_san_pham") = Int32.Parse(lbTongTien.Text)
        phieu_nhap("pn_tong_khuyen_mai") = 0
        phieu_nhap("pn_tong_tien") = phieu_nhap("pn_tong_san_pham") - phieu_nhap("pn_tong_khuyen_mai")
        phieu_nhap("pn_ten_nha_cung_cap") = tbTen.Text
        phieu_nhap("pn_nha_cung_cap") = nha_cung_cap("ncc_ma")
        phieu_nhap("pn_ghi_chu") = tbGhiChu.Text
        phieu_nhap("pn_trang_thai") = 1

        dsPhieuNhap.Rows.Add(phieu_nhap)
        XL_DuLieu.GhiDuLieu("PhieuNhap", dsPhieuNhap)

        For Each ctpn In dsChiTietPhieuNhap.Rows
            ctpn("ctpn_ma_phieu_nhap") = phieu_nhap("pn_ma")
        Next

        XL_DuLieu.GhiDuLieu("ChiTietPhieuNhap", dsChiTietPhieuNhap)

        TatManHinh()
    End Sub

    Sub TatManHinh()
        Dim frm As frmNhapHang = Me.Tag
        frm.HienThiDSNhapHang()
        Me.Close()
    End Sub

    Private Sub bCapNhat_Click(sender As Object, e As EventArgs) Handles bCapNhat.Click
        If tbDienThoai.Text = "" Or tbTen.Text = "" Then
            MessageBox.Show("Vui long dien thong tin nha cung cap!", "Thong bao")
            Return
        Else
            If IsDBNull(nha_cung_cap("ncc_ma")) Then
                nha_cung_cap("ncc_ten") = tbTen.Text
                nha_cung_cap("ncc_dia_chi") = tbDiaChi.Text
                XL_DuLieu.GhiDuLieu("NhaCungCap", dsNhaCungCap)
            End If
        End If

        Dim phieu_nhap = dsPhieuNhap.NewRow()
        phieu_nhap("pn_ngay") = dtpNgay.Value
        phieu_nhap("pn_tong_san_pham") = Int32.Parse(lbTongTien.Text)
        phieu_nhap("pn_tong_khuyen_mai") = 0
        phieu_nhap("pn_tong_tien") = phieu_nhap("pn_tong_san_pham") - phieu_nhap("pn_tong_khuyen_mai")
        phieu_nhap("pn_ten_nha_cung_cap") = tbTen.Text
        phieu_nhap("pn_nha_cung_cap") = nha_cung_cap("ncc_ma")
        phieu_nhap("pn_ghi_chu") = tbGhiChu.Text


        XL_DuLieu.GhiDuLieu("PhieuNhap", dsPhieuNhap)

        For Each ctpn In dsChiTietPhieuNhap.Rows
            ctpn("ctpn_ma_phieu_nhap") = phieu_nhap("pn_ma")
        Next

        XL_DuLieu.GhiDuLieu("ChiTietPhieuNhap", dsChiTietPhieuNhap)

        TatManHinh()
    End Sub
End Class