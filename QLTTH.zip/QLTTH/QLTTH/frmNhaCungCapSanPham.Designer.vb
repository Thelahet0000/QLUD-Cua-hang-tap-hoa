﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNhaCungCapSanPham
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        cbSanPham = New ComboBox()
        tbGia = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        bCapNhat = New Button()
        bHuy = New Button()
        lNhaCungCap = New Label()
        bThem = New Button()
        lGhiChu = New Label()
        tbGhiChu = New TextBox()
        SuspendLayout()
        ' 
        ' cbSanPham
        ' 
        cbSanPham.FormattingEnabled = True
        cbSanPham.Location = New Point(116, 52)
        cbSanPham.Name = "cbSanPham"
        cbSanPham.Size = New Size(121, 23)
        cbSanPham.TabIndex = 0
        ' 
        ' tbGia
        ' 
        tbGia.Location = New Point(116, 95)
        tbGia.Name = "tbGia"
        tbGia.Size = New Size(121, 23)
        tbGia.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(33, 55)
        Label1.Name = "Label1"
        Label1.Size = New Size(63, 15)
        Label1.TabIndex = 2
        Label1.Text = "San Pham:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(33, 103)
        Label2.Name = "Label2"
        Label2.Size = New Size(27, 15)
        Label2.TabIndex = 3
        Label2.Text = "Gia:"
        ' 
        ' bCapNhat
        ' 
        bCapNhat.DialogResult = DialogResult.OK
        bCapNhat.Location = New Point(271, 52)
        bCapNhat.Name = "bCapNhat"
        bCapNhat.Size = New Size(75, 23)
        bCapNhat.TabIndex = 4
        bCapNhat.Text = "Cap Nhat"
        bCapNhat.UseVisualStyleBackColor = True
        ' 
        ' bHuy
        ' 
        bHuy.DialogResult = DialogResult.Cancel
        bHuy.Location = New Point(271, 99)
        bHuy.Name = "bHuy"
        bHuy.Size = New Size(75, 23)
        bHuy.TabIndex = 5
        bHuy.Text = "Huy"
        bHuy.UseVisualStyleBackColor = True
        ' 
        ' lNhaCungCap
        ' 
        lNhaCungCap.AutoSize = True
        lNhaCungCap.Location = New Point(33, 19)
        lNhaCungCap.Name = "lNhaCungCap"
        lNhaCungCap.Size = New Size(27, 15)
        lNhaCungCap.TabIndex = 6
        lNhaCungCap.Text = "Gia:"
        ' 
        ' bThem
        ' 
        bThem.DialogResult = DialogResult.OK
        bThem.Location = New Point(271, 51)
        bThem.Name = "bThem"
        bThem.Size = New Size(75, 23)
        bThem.TabIndex = 7
        bThem.Text = "Them"
        bThem.UseVisualStyleBackColor = True
        ' 
        ' lGhiChu
        ' 
        lGhiChu.AutoSize = True
        lGhiChu.Location = New Point(33, 152)
        lGhiChu.Name = "lGhiChu"
        lGhiChu.Size = New Size(51, 15)
        lGhiChu.TabIndex = 9
        lGhiChu.Text = "Ghi chu:"
        ' 
        ' tbGhiChu
        ' 
        tbGhiChu.Location = New Point(116, 144)
        tbGhiChu.Name = "tbGhiChu"
        tbGhiChu.Size = New Size(121, 23)
        tbGhiChu.TabIndex = 8
        ' 
        ' frmNhaCungCapSanPham
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(378, 197)
        Controls.Add(lGhiChu)
        Controls.Add(tbGhiChu)
        Controls.Add(bThem)
        Controls.Add(lNhaCungCap)
        Controls.Add(bHuy)
        Controls.Add(bCapNhat)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(tbGia)
        Controls.Add(cbSanPham)
        Name = "frmNhaCungCapSanPham"
        Text = "Thong tin san pham cua nha cung cap"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents cbSanPham As ComboBox
    Friend WithEvents tbGia As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents bCapNhat As Button
    Friend WithEvents bHuy As Button
    Friend WithEvents lNhaCungCap As Label
    Friend WithEvents bThem As Button
    Friend WithEvents lGhiChu As Label
    Friend WithEvents tbGhiChu As TextBox
End Class
