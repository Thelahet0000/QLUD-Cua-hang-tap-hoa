﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNhapHang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        tbTimKiem = New TextBox()
        bCapNhat = New Button()
        bTaoDon = New Button()
        dtpNgayHienTai = New DateTimePicker()
        dgvDSPhieuNhap = New DataGridView()
        CType(dgvDSPhieuNhap, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' tbTimKiem
        ' 
        tbTimKiem.Location = New Point(22, 15)
        tbTimKiem.Name = "tbTimKiem"
        tbTimKiem.Size = New Size(270, 23)
        tbTimKiem.TabIndex = 15
        ' 
        ' bCapNhat
        ' 
        bCapNhat.Location = New Point(513, 15)
        bCapNhat.Name = "bCapNhat"
        bCapNhat.Size = New Size(75, 23)
        bCapNhat.TabIndex = 14
        bCapNhat.Text = "Cap Nhat"
        bCapNhat.UseVisualStyleBackColor = True
        ' 
        ' bTaoDon
        ' 
        bTaoDon.Location = New Point(417, 14)
        bTaoDon.Name = "bTaoDon"
        bTaoDon.Size = New Size(75, 23)
        bTaoDon.TabIndex = 13
        bTaoDon.Text = "Tao don"
        bTaoDon.UseVisualStyleBackColor = True
        ' 
        ' dtpNgayHienTai
        ' 
        dtpNgayHienTai.CustomFormat = "dd/MM/yyyy"
        dtpNgayHienTai.Format = DateTimePickerFormat.Custom
        dtpNgayHienTai.Location = New Point(308, 15)
        dtpNgayHienTai.Name = "dtpNgayHienTai"
        dtpNgayHienTai.Size = New Size(85, 23)
        dtpNgayHienTai.TabIndex = 12
        ' 
        ' dgvDSPhieuNhap
        ' 
        dgvDSPhieuNhap.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDSPhieuNhap.Location = New Point(22, 46)
        dgvDSPhieuNhap.Name = "dgvDSPhieuNhap"
        dgvDSPhieuNhap.Size = New Size(579, 366)
        dgvDSPhieuNhap.TabIndex = 11
        ' 
        ' NhapHang
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(622, 430)
        Controls.Add(tbTimKiem)
        Controls.Add(bCapNhat)
        Controls.Add(bTaoDon)
        Controls.Add(dtpNgayHienTai)
        Controls.Add(dgvDSPhieuNhap)
        Name = "NhapHang"
        Text = "NhapHang"
        CType(dgvDSPhieuNhap, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents tbTimKiem As TextBox
    Friend WithEvents bCapNhat As Button
    Friend WithEvents bTaoDon As Button
    Friend WithEvents dtpNgayHienTai As DateTimePicker
    Friend WithEvents dgvDSPhieuNhap As DataGridView
End Class
