﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        MenuStrip1 = New MenuStrip()
        ThongTinToolStripMenuItem = New ToolStripMenuItem()
        ThongTinPhanMemToolStripMenuItem = New ToolStripMenuItem()
        BackupToolStripMenuItem = New ToolStripMenuItem()
        ThoatToolStripMenuItem = New ToolStripMenuItem()
        QuanLyToolStripMenuItem = New ToolStripMenuItem()
        MenuToolStripMenuItem = New ToolStripMenuItem()
        ToolStripSeparator1 = New ToolStripSeparator()
        NhanToolStripMenuItem = New ToolStripMenuItem()
        ToolStripSeparator3 = New ToolStripSeparator()
        NhaCungCapToolStripMenuItem = New ToolStripMenuItem()
        KhuVucToolStripMenuItem = New ToolStripMenuItem()
        BanHangToolStripMenuItem = New ToolStripMenuItem()
        DonHangToolStripMenuItem = New ToolStripMenuItem()
        KhoToolStripMenuItem = New ToolStripMenuItem()
        DanhSachPhieuNhapToolStripMenuItem = New ToolStripMenuItem()
        BaoCaoToolStripMenuItem = New ToolStripMenuItem()
        ThongKeDoanhThuToolStripMenuItem = New ToolStripMenuItem()
        MenuStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' MenuStrip1
        ' 
        MenuStrip1.Items.AddRange(New ToolStripItem() {ThongTinToolStripMenuItem, QuanLyToolStripMenuItem, BanHangToolStripMenuItem, KhoToolStripMenuItem, BaoCaoToolStripMenuItem})
        MenuStrip1.Location = New Point(0, 0)
        MenuStrip1.Name = "MenuStrip1"
        MenuStrip1.Size = New Size(800, 24)
        MenuStrip1.TabIndex = 0
        MenuStrip1.Text = "MenuStrip1"
        ' 
        ' ThongTinToolStripMenuItem
        ' 
        ThongTinToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {ThongTinPhanMemToolStripMenuItem, BackupToolStripMenuItem, ThoatToolStripMenuItem})
        ThongTinToolStripMenuItem.Name = "ThongTinToolStripMenuItem"
        ThongTinToolStripMenuItem.Size = New Size(70, 20)
        ThongTinToolStripMenuItem.Text = "Thong tin"
        ' 
        ' ThongTinPhanMemToolStripMenuItem
        ' 
        ThongTinPhanMemToolStripMenuItem.Name = "ThongTinPhanMemToolStripMenuItem"
        ThongTinPhanMemToolStripMenuItem.Size = New Size(186, 22)
        ThongTinPhanMemToolStripMenuItem.Text = "Thong tin phan mem"
        ' 
        ' BackupToolStripMenuItem
        ' 
        BackupToolStripMenuItem.Name = "BackupToolStripMenuItem"
        BackupToolStripMenuItem.Size = New Size(186, 22)
        BackupToolStripMenuItem.Text = "Backup & Restore"
        ' 
        ' ThoatToolStripMenuItem
        ' 
        ThoatToolStripMenuItem.Name = "ThoatToolStripMenuItem"
        ThoatToolStripMenuItem.Size = New Size(186, 22)
        ThoatToolStripMenuItem.Text = "Thoat"
        ' 
        ' QuanLyToolStripMenuItem
        ' 
        QuanLyToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {MenuToolStripMenuItem, ToolStripSeparator1, NhanToolStripMenuItem, ToolStripSeparator3, NhaCungCapToolStripMenuItem, KhuVucToolStripMenuItem})
        QuanLyToolStripMenuItem.Name = "QuanLyToolStripMenuItem"
        QuanLyToolStripMenuItem.Size = New Size(62, 20)
        QuanLyToolStripMenuItem.Text = "Quan Ly"
        ' 
        ' MenuToolStripMenuItem
        ' 
        MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        MenuToolStripMenuItem.Size = New Size(180, 22)
        MenuToolStripMenuItem.Text = "San pham"
        ' 
        ' ToolStripSeparator1
        ' 
        ToolStripSeparator1.Name = "ToolStripSeparator1"
        ToolStripSeparator1.Size = New Size(177, 6)
        ' 
        ' NhanToolStripMenuItem
        ' 
        NhanToolStripMenuItem.Name = "NhanToolStripMenuItem"
        NhanToolStripMenuItem.Size = New Size(180, 22)
        NhanToolStripMenuItem.Text = "Nhan vien"
        ' 
        ' ToolStripSeparator3
        ' 
        ToolStripSeparator3.Name = "ToolStripSeparator3"
        ToolStripSeparator3.Size = New Size(177, 6)
        ' 
        ' NhaCungCapToolStripMenuItem
        ' 
        NhaCungCapToolStripMenuItem.Name = "NhaCungCapToolStripMenuItem"
        NhaCungCapToolStripMenuItem.Size = New Size(180, 22)
        NhaCungCapToolStripMenuItem.Text = "Nha cung cap"
        ' 
        ' KhuVucToolStripMenuItem
        ' 
        KhuVucToolStripMenuItem.Name = "KhuVucToolStripMenuItem"
        KhuVucToolStripMenuItem.Size = New Size(180, 22)
        KhuVucToolStripMenuItem.Text = "Khu vuc"
        ' 
        ' BanHangToolStripMenuItem
        ' 
        BanHangToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {DonHangToolStripMenuItem})
        BanHangToolStripMenuItem.Name = "BanHangToolStripMenuItem"
        BanHangToolStripMenuItem.Size = New Size(71, 20)
        BanHangToolStripMenuItem.Text = "Ban Hang"
        ' 
        ' DonHangToolStripMenuItem
        ' 
        DonHangToolStripMenuItem.Name = "DonHangToolStripMenuItem"
        DonHangToolStripMenuItem.Size = New Size(180, 22)
        DonHangToolStripMenuItem.Text = "Ban Hang"
        ' 
        ' KhoToolStripMenuItem
        ' 
        KhoToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {DanhSachPhieuNhapToolStripMenuItem})
        KhoToolStripMenuItem.Name = "KhoToolStripMenuItem"
        KhoToolStripMenuItem.Size = New Size(40, 20)
        KhoToolStripMenuItem.Text = "Kho"
        ' 
        ' DanhSachPhieuNhapToolStripMenuItem
        ' 
        DanhSachPhieuNhapToolStripMenuItem.Name = "DanhSachPhieuNhapToolStripMenuItem"
        DanhSachPhieuNhapToolStripMenuItem.Size = New Size(180, 22)
        DanhSachPhieuNhapToolStripMenuItem.Text = "Nhap hang"
        ' 
        ' BaoCaoToolStripMenuItem
        ' 
        BaoCaoToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {ThongKeDoanhThuToolStripMenuItem})
        BaoCaoToolStripMenuItem.Name = "BaoCaoToolStripMenuItem"
        BaoCaoToolStripMenuItem.Size = New Size(61, 20)
        BaoCaoToolStripMenuItem.Text = "Bao cao"
        ' 
        ' ThongKeDoanhThuToolStripMenuItem
        ' 
        ThongKeDoanhThuToolStripMenuItem.Name = "ThongKeDoanhThuToolStripMenuItem"
        ThongKeDoanhThuToolStripMenuItem.Size = New Size(181, 22)
        ThongKeDoanhThuToolStripMenuItem.Text = "Thong ke doanh thu"
        ' 
        ' frmMain
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(MenuStrip1)
        IsMdiContainer = True
        MainMenuStrip = MenuStrip1
        Name = "frmMain"
        Text = "Form1"
        WindowState = FormWindowState.Maximized
        MenuStrip1.ResumeLayout(False)
        MenuStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ThongTinToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents QuanLyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BanHangToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents KhoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MenuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NhanToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DanhSachDonHangToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents KhachHangToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DanhSachPhieuNhapToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ThoatToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ThongTinPhanMemToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents NhaCungCapToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DanhSachPhieuChiToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents KhuVucToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DonHangToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BaoCaoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ThongKeDoanhThuToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BackupToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ThongKeToolStripMenuItem As ToolStripMenuItem

End Class
