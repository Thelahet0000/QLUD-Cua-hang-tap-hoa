﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBackupRestore
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        bBackup = New Button()
        bRestore = New Button()
        OpenFileDialog1 = New OpenFileDialog()
        SuspendLayout()
        ' 
        ' bBackup
        ' 
        bBackup.Location = New Point(22, 12)
        bBackup.Name = "bBackup"
        bBackup.Size = New Size(91, 39)
        bBackup.TabIndex = 0
        bBackup.Text = "Back-up"
        bBackup.UseVisualStyleBackColor = True
        ' 
        ' bRestore
        ' 
        bRestore.Location = New Point(152, 12)
        bRestore.Name = "bRestore"
        bRestore.Size = New Size(91, 39)
        bRestore.TabIndex = 1
        bRestore.Text = "Restore"
        bRestore.UseVisualStyleBackColor = True
        ' 
        ' OpenFileDialog1
        ' 
        OpenFileDialog1.FileName = "OpenFileDialog1"
        ' 
        ' frmBackupRestore
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(281, 91)
        Controls.Add(bRestore)
        Controls.Add(bBackup)
        Name = "frmBackupRestore"
        Text = "Back-up & Restore"
        ResumeLayout(False)
    End Sub

    Friend WithEvents bBackup As Button
    Friend WithEvents bRestore As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
End Class
