﻿Public Class frmSanPham
    Dim dsSanPham As DataTable
    Dim dsSanPhamView As DataView

    Sub HienThiDSSanPham()
        Dim truy_van As String = "Select * from SanPham where sp_xoa = " + cbKhoiPhuc.Checked.ToString()
        dsSanPham = XL_DuLieu.DocDuLieu(truy_van)
        dsSanPhamView = New DataView(dsSanPham)
        dgvSanPham.DataSource = dsSanPhamView

        dgvSanPham.Columns(0).Visible = False
        dgvSanPham.Columns(6).Visible = False
    End Sub
    Private Sub frmSanPham_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim truy_van As String = "Select * from SanPham where sp_xoa = false"
        dsSanPham = XL_DuLieu.DocDuLieu(truy_van)

        HienThiDSSanPham()
        bKhoiPhuc.Enabled = False
    End Sub

    Private Sub bThemSP_Click(sender As Object, e As EventArgs) Handles bThemSP.Click
        Dim sanPham As DataRow = dsSanPham.NewRow()
        sanPham("sp_code") = tbMaSP.Text
        sanPham("sp_ten") = tbTenSP.Text
        sanPham("sp_mo_ta") = tbMotaSP.Text

        dsSanPham.Rows.Add(sanPham)
        XL_DuLieu.GhiDuLieu("SanPham", dsSanPham)
        MessageBox.Show("Them san pham thanh cong", "Thong bao", MessageBoxButtons.OK)
    End Sub

    Private Sub bCapNhatSP_Click(sender As Object, e As EventArgs) Handles bCapNhatSP.Click
        If dgvSanPham.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvSanPham.SelectedCells(0).RowIndex
            Dim sanPhamView As DataRowView = dgvSanPham.Rows(row_index).DataBoundItem
            Dim sanPham As DataRow = sanPhamView.Row

            sanPham("sp_code") = tbMaSP.Text
            sanPham("sp_ten") = tbTenSP.Text
            sanPham("sp_mo_ta") = tbMotaSP.Text

            XL_DuLieu.GhiDuLieu("SanPham", dsSanPham)
            MessageBox.Show("Cap nhat san pham thanh cong", "Thong bao", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub bXoaSP_Click(sender As Object, e As EventArgs) Handles bXoaSP.Click
        If dgvSanPham.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvSanPham.SelectedCells(0).RowIndex
            Dim sanPhamView As DataRowView = dgvSanPham.Rows(row_index).DataBoundItem
            Dim sanPham As DataRow = sanPhamView.Row

            Dim chuoi As String = String.Format("Anh/Chi co that su muon xoa '{0}' khong?", sanPham("sp_code"), sanPham("sp_ten"))
            Dim luachon As DialogResult = MessageBox.Show(chuoi, "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If luachon = DialogResult.Yes Then
                sanPham("sp_xoa") = True

                XL_DuLieu.GhiDuLieu("SanPham", dsSanPham)
                dsSanPham.Rows.Remove(sanPham)
                MessageBox.Show("Xoa san pham thanh cong", "Thong bao", MessageBoxButtons.OK)
            End If
        End If
    End Sub

    Private Sub dgvSanPham_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSanPham.CellClick
        If dgvSanPham.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvSanPham.SelectedCells(0).RowIndex
            Dim sanPhamView As DataRowView = dgvSanPham.Rows(row_index).DataBoundItem
            Dim sanPham As DataRow = sanPhamView.Row

            tbMaSP.Text = sanPham("sp_code")
            tbTenSP.Text = sanPham("sp_ten")
            tbMotaSP.Text = sanPham("sp_mo_ta")
        End If
    End Sub

    Private Sub tbTimKiem_TextChanged(sender As Object, e As EventArgs) Handles tbTimKiem.TextChanged
        If tbTimKiem.Text <> "" Then
            dsSanPhamView.RowFilter = String.Format("sp_ten like '%{0}%' or sp_code like '%{0}%'", tbTimKiem.Text)
        Else
            dsSanPhamView.RowFilter = ""
        End If
    End Sub

    Private Sub cbKhoiPhuc_CheckedChanged(sender As Object, e As EventArgs) Handles cbKhoiPhuc.CheckedChanged
        HienThiDSSanPham()
        If cbKhoiPhuc.Checked Then
            bKhoiPhuc.Enabled = True

            bThemSP.Enabled = False
            bCapNhatSP.Enabled = False
            bXoaSP.Enabled = False
        Else
            bKhoiPhuc.Enabled = False

            bThemSP.Enabled = True
            bCapNhatSP.Enabled = True
            bXoaSP.Enabled = True
        End If
    End Sub

    Private Sub bKhoiPhuc_Click(sender As Object, e As EventArgs) Handles bKhoiPhuc.Click
        If dgvSanPham.SelectedCells.Count() > 0 Then
            Dim row_index As Integer = dgvSanPham.SelectedCells(0).RowIndex
            Dim sanPhamView As DataRowView = dgvSanPham.Rows(row_index).DataBoundItem
            Dim sanPham As DataRow = sanPhamView.Row

            Dim chuoi As String = String.Format("Anh/Chi co that su muon phuc hoi '{0}' khong?", sanPham("sp_code"), sanPham("sp_ten"))
            Dim luachon As DialogResult = MessageBox.Show(chuoi, "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If luachon = DialogResult.Yes Then
                sanPham("sp_xoa") = False

                XL_DuLieu.GhiDuLieu("SanPham", dsSanPham)
                dsSanPham.Rows.Remove(sanPham)
                MessageBox.Show("Khoi phuc san pham thanh cong", "Thong bao", MessageBoxButtons.OK)
            End If
        End If
    End Sub
End Class