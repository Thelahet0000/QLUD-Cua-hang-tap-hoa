﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNhaCungCap
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        bKhoiPhuc = New Button()
        cbKhoiPhuc = New CheckBox()
        tbTimKiem = New TextBox()
        bXoa = New Button()
        bCapNhat = New Button()
        bThem = New Button()
        tbTen = New TextBox()
        tbDiaChi = New TextBox()
        lbDiaChi = New Label()
        lbTen = New Label()
        lbMa = New Label()
        tbMa = New TextBox()
        dgvDanhSach = New DataGridView()
        tbSdt = New TextBox()
        lbSdt = New Label()
        tbGhiChu = New TextBox()
        lbGhiChu = New Label()
        dgvDSSanPham = New DataGridView()
        bXoaSanPham = New Button()
        bCapNhatSanPham = New Button()
        bThemSanPham = New Button()
        CType(dgvDanhSach, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgvDSSanPham, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' bKhoiPhuc
        ' 
        bKhoiPhuc.Location = New Point(682, 286)
        bKhoiPhuc.Name = "bKhoiPhuc"
        bKhoiPhuc.Size = New Size(75, 23)
        bKhoiPhuc.TabIndex = 35
        bKhoiPhuc.Text = "Khoi phuc"
        bKhoiPhuc.UseVisualStyleBackColor = True
        ' 
        ' cbKhoiPhuc
        ' 
        cbKhoiPhuc.AutoSize = True
        cbKhoiPhuc.Location = New Point(457, 289)
        cbKhoiPhuc.Name = "cbKhoiPhuc"
        cbKhoiPhuc.Size = New Size(199, 19)
        cbKhoiPhuc.TabIndex = 34
        cbKhoiPhuc.Text = "Hien thi cac nha cung cap bi xoa"
        cbKhoiPhuc.UseVisualStyleBackColor = True
        ' 
        ' tbTimKiem
        ' 
        tbTimKiem.Location = New Point(21, 12)
        tbTimKiem.Name = "tbTimKiem"
        tbTimKiem.Size = New Size(414, 23)
        tbTimKiem.TabIndex = 33
        ' 
        ' bXoa
        ' 
        bXoa.Location = New Point(704, 238)
        bXoa.Name = "bXoa"
        bXoa.Size = New Size(75, 23)
        bXoa.TabIndex = 31
        bXoa.Text = "Xoa"
        bXoa.UseVisualStyleBackColor = True
        ' 
        ' bCapNhat
        ' 
        bCapNhat.Location = New Point(594, 238)
        bCapNhat.Name = "bCapNhat"
        bCapNhat.Size = New Size(75, 23)
        bCapNhat.TabIndex = 29
        bCapNhat.Text = "Cap Nhat"
        bCapNhat.UseVisualStyleBackColor = True
        ' 
        ' bThem
        ' 
        bThem.Location = New Point(486, 238)
        bThem.Name = "bThem"
        bThem.Size = New Size(75, 23)
        bThem.TabIndex = 27
        bThem.Text = "Them"
        bThem.UseVisualStyleBackColor = True
        ' 
        ' tbTen
        ' 
        tbTen.Location = New Point(585, 55)
        tbTen.Name = "tbTen"
        tbTen.Size = New Size(153, 23)
        tbTen.TabIndex = 24
        ' 
        ' tbDiaChi
        ' 
        tbDiaChi.Location = New Point(585, 94)
        tbDiaChi.Name = "tbDiaChi"
        tbDiaChi.Size = New Size(153, 23)
        tbDiaChi.TabIndex = 25
        ' 
        ' lbDiaChi
        ' 
        lbDiaChi.AutoSize = True
        lbDiaChi.Location = New Point(486, 97)
        lbDiaChi.Name = "lbDiaChi"
        lbDiaChi.Size = New Size(46, 15)
        lbDiaChi.TabIndex = 30
        lbDiaChi.Text = "Dia chi:"
        ' 
        ' lbTen
        ' 
        lbTen.AutoSize = True
        lbTen.Location = New Point(486, 58)
        lbTen.Name = "lbTen"
        lbTen.Size = New Size(28, 15)
        lbTen.TabIndex = 28
        lbTen.Text = "Ten:"
        ' 
        ' lbMa
        ' 
        lbMa.AutoSize = True
        lbMa.Location = New Point(486, 15)
        lbMa.Name = "lbMa"
        lbMa.Size = New Size(27, 15)
        lbMa.TabIndex = 26
        lbMa.Text = "Ma:"
        ' 
        ' tbMa
        ' 
        tbMa.Location = New Point(585, 12)
        tbMa.Name = "tbMa"
        tbMa.Size = New Size(153, 23)
        tbMa.TabIndex = 23
        ' 
        ' dgvDanhSach
        ' 
        dgvDanhSach.AllowUserToAddRows = False
        dgvDanhSach.AllowUserToDeleteRows = False
        dgvDanhSach.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDanhSach.Location = New Point(21, 47)
        dgvDanhSach.Name = "dgvDanhSach"
        dgvDanhSach.ReadOnly = True
        dgvDanhSach.Size = New Size(414, 567)
        dgvDanhSach.TabIndex = 32
        ' 
        ' tbSdt
        ' 
        tbSdt.Location = New Point(585, 136)
        tbSdt.Name = "tbSdt"
        tbSdt.Size = New Size(153, 23)
        tbSdt.TabIndex = 36
        ' 
        ' lbSdt
        ' 
        lbSdt.AutoSize = True
        lbSdt.Location = New Point(486, 139)
        lbSdt.Name = "lbSdt"
        lbSdt.Size = New Size(27, 15)
        lbSdt.TabIndex = 37
        lbSdt.Text = "Sdt:"
        ' 
        ' tbGhiChu
        ' 
        tbGhiChu.Location = New Point(585, 179)
        tbGhiChu.Name = "tbGhiChu"
        tbGhiChu.Size = New Size(153, 23)
        tbGhiChu.TabIndex = 38
        ' 
        ' lbGhiChu
        ' 
        lbGhiChu.AutoSize = True
        lbGhiChu.Location = New Point(486, 182)
        lbGhiChu.Name = "lbGhiChu"
        lbGhiChu.Size = New Size(51, 15)
        lbGhiChu.TabIndex = 39
        lbGhiChu.Text = "Ghi chu:"
        ' 
        ' dgvDSSanPham
        ' 
        dgvDSSanPham.AllowUserToAddRows = False
        dgvDSSanPham.AllowUserToDeleteRows = False
        dgvDSSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDSSanPham.Location = New Point(457, 325)
        dgvDSSanPham.Name = "dgvDSSanPham"
        dgvDSSanPham.ReadOnly = True
        dgvDSSanPham.Size = New Size(373, 289)
        dgvDSSanPham.TabIndex = 40
        ' 
        ' bXoaSanPham
        ' 
        bXoaSanPham.Location = New Point(840, 447)
        bXoaSanPham.Name = "bXoaSanPham"
        bXoaSanPham.Size = New Size(75, 23)
        bXoaSanPham.TabIndex = 43
        bXoaSanPham.Text = "Xoa"
        bXoaSanPham.UseVisualStyleBackColor = True
        ' 
        ' bCapNhatSanPham
        ' 
        bCapNhatSanPham.Location = New Point(840, 399)
        bCapNhatSanPham.Name = "bCapNhatSanPham"
        bCapNhatSanPham.Size = New Size(75, 23)
        bCapNhatSanPham.TabIndex = 42
        bCapNhatSanPham.Text = "Cap Nhat"
        bCapNhatSanPham.UseVisualStyleBackColor = True
        ' 
        ' bThemSanPham
        ' 
        bThemSanPham.Location = New Point(840, 348)
        bThemSanPham.Name = "bThemSanPham"
        bThemSanPham.Size = New Size(75, 23)
        bThemSanPham.TabIndex = 41
        bThemSanPham.Text = "Them"
        bThemSanPham.UseVisualStyleBackColor = True
        ' 
        ' frmNhaCungCap
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(927, 626)
        Controls.Add(bXoaSanPham)
        Controls.Add(bCapNhatSanPham)
        Controls.Add(bThemSanPham)
        Controls.Add(dgvDSSanPham)
        Controls.Add(tbGhiChu)
        Controls.Add(lbGhiChu)
        Controls.Add(tbSdt)
        Controls.Add(lbSdt)
        Controls.Add(bKhoiPhuc)
        Controls.Add(cbKhoiPhuc)
        Controls.Add(tbTimKiem)
        Controls.Add(bXoa)
        Controls.Add(bCapNhat)
        Controls.Add(bThem)
        Controls.Add(tbTen)
        Controls.Add(tbDiaChi)
        Controls.Add(lbDiaChi)
        Controls.Add(lbTen)
        Controls.Add(lbMa)
        Controls.Add(tbMa)
        Controls.Add(dgvDanhSach)
        Name = "frmNhaCungCap"
        Text = "frmNhaCungCap"
        CType(dgvDanhSach, ComponentModel.ISupportInitialize).EndInit()
        CType(dgvDSSanPham, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents bKhoiPhuc As Button
    Friend WithEvents cbKhoiPhuc As CheckBox
    Friend WithEvents tbTimKiem As TextBox
    Friend WithEvents bXoa As Button
    Friend WithEvents bCapNhat As Button
    Friend WithEvents bThem As Button
    Friend WithEvents tbTen As TextBox
    Friend WithEvents tbDiaChi As TextBox
    Friend WithEvents lbDiaChi As Label
    Friend WithEvents lbTen As Label
    Friend WithEvents lbMa As Label
    Friend WithEvents tbMa As TextBox
    Friend WithEvents dgvDanhSach As DataGridView
    Friend WithEvents tbSdt As TextBox
    Friend WithEvents lbSdt As Label
    Friend WithEvents tbGhiChu As TextBox
    Friend WithEvents lbGhiChu As Label
    Friend WithEvents dgvDSSanPham As DataGridView
    Friend WithEvents bXoaSanPham As Button
    Friend WithEvents bCapNhatSanPham As Button
    Friend WithEvents bThemSanPham As Button
End Class
