﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPhieuNhap
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label3 = New Label()
        tbDiaChi = New TextBox()
        tbTen = New TextBox()
        Label4 = New Label()
        bTao = New Button()
        bCapNhat = New Button()
        lbTongTien = New Label()
        bXoa = New Button()
        bThem = New Button()
        dgvDSChiTiet = New DataGridView()
        Label2 = New Label()
        tbGhiChu = New TextBox()
        tbDienThoai = New TextBox()
        Label1 = New Label()
        lNgay = New Label()
        dtpNgay = New DateTimePicker()
        dgvDSSanPham = New DataGridView()
        cbKhuVuc = New ComboBox()
        Label5 = New Label()
        CType(dgvDSChiTiet, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgvDSSanPham, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(521, 86)
        Label3.Name = "Label3"
        Label3.Size = New Size(46, 15)
        Label3.TabIndex = 33
        Label3.Text = "Dia chi:"
        ' 
        ' tbDiaChi
        ' 
        tbDiaChi.Location = New Point(610, 78)
        tbDiaChi.Name = "tbDiaChi"
        tbDiaChi.Size = New Size(393, 23)
        tbDiaChi.TabIndex = 20
        ' 
        ' tbTen
        ' 
        tbTen.Location = New Point(854, 49)
        tbTen.Name = "tbTen"
        tbTen.Size = New Size(149, 23)
        tbTen.TabIndex = 18
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(764, 57)
        Label4.Name = "Label4"
        Label4.Size = New Size(84, 15)
        Label4.TabIndex = 32
        Label4.Text = "Nha cung cap:"
        ' 
        ' bTao
        ' 
        bTao.Location = New Point(988, 580)
        bTao.Name = "bTao"
        bTao.Size = New Size(75, 23)
        bTao.TabIndex = 28
        bTao.Text = "Tao"
        bTao.UseVisualStyleBackColor = True
        ' 
        ' bCapNhat
        ' 
        bCapNhat.Location = New Point(987, 551)
        bCapNhat.Name = "bCapNhat"
        bCapNhat.Size = New Size(75, 23)
        bCapNhat.TabIndex = 26
        bCapNhat.Text = "Cap Nhat"
        bCapNhat.UseVisualStyleBackColor = True
        ' 
        ' lbTongTien
        ' 
        lbTongTien.AutoSize = True
        lbTongTien.Location = New Point(1007, 512)
        lbTongTien.Name = "lbTongTien"
        lbTongTien.Size = New Size(56, 15)
        lbTongTien.TabIndex = 31
        lbTongTien.Text = "Tong tien"
        ' 
        ' bXoa
        ' 
        bXoa.Location = New Point(433, 211)
        bXoa.Name = "bXoa"
        bXoa.Size = New Size(75, 23)
        bXoa.TabIndex = 25
        bXoa.Text = "<"
        bXoa.UseVisualStyleBackColor = True
        ' 
        ' bThem
        ' 
        bThem.Location = New Point(432, 182)
        bThem.Name = "bThem"
        bThem.Size = New Size(75, 23)
        bThem.TabIndex = 24
        bThem.Text = ">"
        bThem.UseVisualStyleBackColor = True
        ' 
        ' dgvDSChiTiet
        ' 
        dgvDSChiTiet.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDSChiTiet.Location = New Point(518, 138)
        dgvDSChiTiet.Name = "dgvDSChiTiet"
        dgvDSChiTiet.Size = New Size(545, 360)
        dgvDSChiTiet.TabIndex = 29
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(521, 117)
        Label2.Name = "Label2"
        Label2.Size = New Size(51, 15)
        Label2.TabIndex = 27
        Label2.Text = "Ghi chu:"
        ' 
        ' tbGhiChu
        ' 
        tbGhiChu.Location = New Point(610, 109)
        tbGhiChu.Name = "tbGhiChu"
        tbGhiChu.Size = New Size(393, 23)
        tbGhiChu.TabIndex = 23
        ' 
        ' tbDienThoai
        ' 
        tbDienThoai.Location = New Point(609, 49)
        tbDienThoai.Name = "tbDienThoai"
        tbDienThoai.Size = New Size(149, 23)
        tbDienThoai.TabIndex = 17
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(520, 57)
        Label1.Name = "Label1"
        Label1.Size = New Size(64, 15)
        Label1.TabIndex = 22
        Label1.Text = "Dien thoai:"
        ' 
        ' lNgay
        ' 
        lNgay.AutoSize = True
        lNgay.Location = New Point(521, 22)
        lNgay.Name = "lNgay"
        lNgay.Size = New Size(38, 15)
        lNgay.TabIndex = 21
        lNgay.Text = "Ngay:"
        ' 
        ' dtpNgay
        ' 
        dtpNgay.CustomFormat = "dd/MM/yyyy"
        dtpNgay.Format = DateTimePickerFormat.Custom
        dtpNgay.Location = New Point(610, 16)
        dtpNgay.Name = "dtpNgay"
        dtpNgay.Size = New Size(85, 23)
        dtpNgay.TabIndex = 19
        ' 
        ' dgvDSSanPham
        ' 
        dgvDSSanPham.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvDSSanPham.Location = New Point(12, 16)
        dgvDSSanPham.Name = "dgvDSSanPham"
        dgvDSSanPham.Size = New Size(414, 482)
        dgvDSSanPham.TabIndex = 30
        ' 
        ' cbKhuVuc
        ' 
        cbKhuVuc.FormattingEnabled = True
        cbKhuVuc.Location = New Point(854, 12)
        cbKhuVuc.Name = "cbKhuVuc"
        cbKhuVuc.Size = New Size(149, 23)
        cbKhuVuc.TabIndex = 34
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(764, 15)
        Label5.Name = "Label5"
        Label5.Size = New Size(53, 15)
        Label5.TabIndex = 35
        Label5.Text = "Khu vuc:"
        ' 
        ' frmPhieuNhap
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1077, 625)
        Controls.Add(Label5)
        Controls.Add(cbKhuVuc)
        Controls.Add(Label3)
        Controls.Add(tbDiaChi)
        Controls.Add(tbTen)
        Controls.Add(Label4)
        Controls.Add(bTao)
        Controls.Add(bCapNhat)
        Controls.Add(lbTongTien)
        Controls.Add(bXoa)
        Controls.Add(bThem)
        Controls.Add(dgvDSChiTiet)
        Controls.Add(Label2)
        Controls.Add(tbGhiChu)
        Controls.Add(tbDienThoai)
        Controls.Add(Label1)
        Controls.Add(lNgay)
        Controls.Add(dtpNgay)
        Controls.Add(dgvDSSanPham)
        Name = "frmPhieuNhap"
        Text = "frmPhieuNhapHang"
        CType(dgvDSChiTiet, ComponentModel.ISupportInitialize).EndInit()
        CType(dgvDSSanPham, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label3 As Label
    Friend WithEvents tbDiaChi As TextBox
    Friend WithEvents tbTen As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents bTao As Button
    Friend WithEvents bCapNhat As Button
    Friend WithEvents lbTongTien As Label
    Friend WithEvents bXoa As Button
    Friend WithEvents bThem As Button
    Friend WithEvents dgvDSChiTiet As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents tbGhiChu As TextBox
    Friend WithEvents tbDienThoai As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lNgay As Label
    Friend WithEvents dtpNgay As DateTimePicker
    Friend WithEvents dgvDSSanPham As DataGridView
    Friend WithEvents cbKhuVuc As ComboBox
    Friend WithEvents Label5 As Label
End Class
