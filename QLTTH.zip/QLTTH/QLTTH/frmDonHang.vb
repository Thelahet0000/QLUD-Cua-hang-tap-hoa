﻿Public Class frmDonHang
    Public ngay As Date

    Dim dsSanPham As DataTable
    Dim dsChiTietDonHang As DataTable
    Dim dsDonHang As DataTable

    Dim dsKhachHang As DataTable
    Dim khach_hang As DataRow

    Public Loai As Integer
    Public don_hang As DataRow

    Private Sub frmDonHang_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpNgay.Value = ngay
        Dim str As String = String.Format(
            "Select sp_ma, sp_ten, mct_gia from MenuChiTiet, SanPham
                where mct_san_pham = sp_ma")
        dsSanPham = XL_DuLieu.DocDuLieu(str)
        dgvDSSanPham.DataSource = dsSanPham

        If Loai = 1 Then
            str = String.Format(
                "Select ctdh_ma, ctdh_ma_don_hang, ctdh_ma_san_pham, sp_ten, ctdh_so_luong, ctdh_gia , 
                ctdh_tong_san_pham, ctdh_khuyen_mai, ctdh_tong_tien, ctdh_ghi_chu, ctdh_xoa
                from ChiTietDonHang, SanPham where ctdh_ma_san_pham = sp_ma"
            )
            dsChiTietDonHang = XL_DuLieu.DocCauTruc(str)

            str = String.Format("select * from DonHang")
            dsDonHang = XL_DuLieu.DocCauTruc(str)
            bCapNhat.Visible = False
            bTao.Visible = True
        Else
            dsChiTietDonHang = XL_DuLieu.DocDuLieu(
                "Select ctdh_ma, ctdh_ma_don_hang, ctdh_ma_san_pham, sp_ten, ctdh_so_luong, ctdh_gia , 
                ctdh_tong_san_pham, ctdh_khuyen_mai, ctdh_tong_tien, ctdh_ghi_chu, ctdh_xoa
                from ChiTietDonHang, SanPham where ctdh_ma_san_pham = sp_ma and ctdh_ma_don_hang=" + don_hang("dh_ma").ToString()
            )
            dsDonHang = XL_DuLieu.DocDuLieu(
                "Select * from DonHang where dh_ma = " + don_hang("dh_ma").ToString()
            )

            dsKhachHang = XL_DuLieu.DocDuLieu("select * from KhachHang where kh_ma = " + don_hang("dh_khach_hang").ToString())
            khach_hang = dsKhachHang.Rows(0)
            tbDienThoai.Text = khach_hang("kh_dien_thoai")
            tbTen.Text = khach_hang("kh_ten")
            tbDiaChi.Text = khach_hang("kh_dia_chi")
            TinhTong()
            bCapNhat.Visible = True
            bTao.Visible = False
        End If
        dgvDSChiTiet.DataSource = dsChiTietDonHang
        dgvDSChiTiet.Columns(0).Visible = False
        dgvDSChiTiet.Columns(0).Visible = False
    End Sub

    Private Sub tbDienThoai_TextChanged(sender As Object, e As EventArgs) Handles tbDienThoai.TextChanged, tbDienThoai.Leave
        Dim str As String = String.Format("Select * from KhachHang where kh_dien_thoai like '{0}'", tbDienThoai.Text)
        dsKhachHang = XL_DuLieu.DocDuLieu(str)
        If dsKhachHang.Rows.Count > 0 Then
            khach_hang = dsKhachHang.Rows(0)
            tbTen.Text = khach_hang("kh_ten")
            tbDiaChi.Text = khach_hang("kh_dia_chi")
        Else
            khach_hang = dsKhachHang.NewRow()
            khach_hang("kh_dien_thoai") = tbDienThoai.Text
            dsKhachHang.Rows.Add(khach_hang)
        End If
    End Sub

    Private Sub bThem_Click(sender As Object, e As EventArgs) Handles bThem.Click
        If dgvDSSanPham.SelectedRows.Count > 0 Then
            Dim san_pham As DataRow = dsSanPham(dgvDSSanPham.SelectedCells(0).RowIndex)
            Dim ctdhs() As DataRow = dsChiTietDonHang.Select("ctdh_ma_san_pham = " + san_pham("sp_ma").ToString())

            If ctdhs.Length > 0 Then
                Dim chi_tiet As DataRow = ctdhs(0)
                chi_tiet("ctdh_so_luong") += 1
                chi_tiet("ctdh_tong_tien") = chi_tiet("ctdh_so_luong") * chi_tiet("ctdh_gia")
                chi_tiet("ctdh_tong_san_pham") = chi_tiet("ctdh_tong_tien")
                chi_tiet("ctdh_khuyen_mai") = 0
            Else
                Dim chi_tiet As DataRow = dsChiTietDonHang.NewRow()
                chi_tiet("ctdh_ma_san_pham") = san_pham("sp_ma")
                chi_tiet("ctdh_gia") = san_pham("mct_gia")
                chi_tiet("ctdh_so_luong") = 1
                chi_tiet("sp_ten") = san_pham("sp_ten")
                chi_tiet("ctdh_tong_tien") = chi_tiet("ctdh_so_luong") * chi_tiet("ctdh_gia")
                chi_tiet("ctdh_tong_san_pham") = chi_tiet("ctdh_tong_tien")
                chi_tiet("ctdh_khuyen_mai") = 0
                dsChiTietDonHang.Rows.Add(chi_tiet)
            End If
            TinhTong()
        End If
    End Sub

    Sub TinhTong()
        Dim TongTien = dsChiTietDonHang.Compute("Sum(ctdh_tong_tien)", String.Empty)
        lbTongTien.Text = TongTien.ToString()
    End Sub

    Private Sub bXoa_Click(sender As Object, e As EventArgs) Handles bXoa.Click
        If dgvDSSanPham.SelectedRows.Count > 0 Then
            Dim chi_tiet As DataRow = dsChiTietDonHang(dgvDSChiTiet.SelectedCells(0).RowIndex)
            Dim so_luong As Integer = chi_tiet("ctdh_so_luong") - 1
            If so_luong <= 0 Then
                If Loai = 1 Then
                    dsChiTietDonHang.Rows.Remove(chi_tiet)
                ElseIf Loai = 2 Then
                    chi_tiet.Delete()
                End If
            Else
                chi_tiet("ctdh_so_luong") = so_luong
                chi_tiet("ctdh_tong_tien") = chi_tiet("ctdh_so_luong") * chi_tiet("ctdh_gia")
                chi_tiet("ctdh_tong_san_pham") = chi_tiet("ctdh_tong_tien")
                chi_tiet("ctdh_khuyen_mai") = 0
            End If
            TinhTong()
        End If
    End Sub

    Private Sub bTao_Click(sender As Object, e As EventArgs) Handles bTao.Click
        If tbDienThoai.Text = "" Or tbTen.Text = "" Then
            MessageBox.Show("Vui long dien thong tin khach hang!", "Thong bao")
            Return
        Else
            If IsDBNull(khach_hang("kh_ma")) Then
                khach_hang("kh_ten") = tbTen.Text
                khach_hang("kh_dia_chi") = tbDiaChi.Text
                XL_DuLieu.GhiDuLieu("KhachHang", dsKhachHang)
            End If
        End If

        Dim don_hang = dsDonHang.NewRow()
        don_hang("dh_ngay") = dtpNgay.Value
        don_hang("dh_tong_san_pham") = Int32.Parse(lbTongTien.Text)
        don_hang("dh_tong_khuyen_mai") = 0
        don_hang("dh_tong_tien") = don_hang("dh_tong_san_pham") - don_hang("dh_tong_khuyen_mai")
        don_hang("dh_ten_khach_hang") = tbTen.Text
        don_hang("dh_khach_hang") = khach_hang("kh_ma")
        don_hang("dh_ghi_chu") = tbGhiChu.Text
        don_hang("dh_trang_thai") = 1

        dsDonHang.Rows.Add(don_hang)
        XL_DuLieu.GhiDuLieu("DonHang", dsDonHang)

        For Each ctdh In dsChiTietDonHang.Rows
            ctdh("ctdh_ma_don_hang") = don_hang("dh_ma")
        Next

        XL_DuLieu.GhiDuLieu("ChiTietDonHang", dsChiTietDonHang)

        TatManHinh()
    End Sub

    Sub TatManHinh()
        Dim frm As frmBanHang = Me.Tag
        frm.HienThiDSDonHang()
        Me.Close()
    End Sub

    Private Sub bCapNhat_Click(sender As Object, e As EventArgs) Handles bCapNhat.Click
        If tbDienThoai.Text = "" Or tbTen.Text = "" Then
            MessageBox.Show("Vui long dien thong tin khach hang!", "Thong bao")
            Return
        Else
            If IsDBNull(khach_hang("kh_ma")) Then
                khach_hang("kh_ten") = tbTen.Text
                khach_hang("kh_dia_chi") = tbDiaChi.Text
                XL_DuLieu.GhiDuLieu("KhachHang", dsKhachHang)
            End If
        End If

        Dim don_hang = dsDonHang.NewRow()
        don_hang("dh_ngay") = dtpNgay.Value
        don_hang("dh_tong_san_pham") = Int32.Parse(lbTongTien.Text)
        don_hang("dh_tong_khuyen_mai") = 0
        don_hang("dh_tong_tien") = don_hang("dh_tong_san_pham") - don_hang("dh_tong_khuyen_mai")
        don_hang("dh_ten_khach_hang") = tbTen.Text
        don_hang("dh_khach_hang") = khach_hang("kh_ma")
        don_hang("dh_ghi_chu") = tbGhiChu.Text

        XL_DuLieu.GhiDuLieu("DonHang", dsDonHang)

        For Each ctdh In dsChiTietDonHang.Rows
            ctdh("ctdh_ma_don_hang") = don_hang("dh_ma")
        Next

        XL_DuLieu.GhiDuLieu("ChiTietDonHang", dsChiTietDonHang)

        TatManHinh()
    End Sub
End Class